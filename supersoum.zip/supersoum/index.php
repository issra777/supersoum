<?php
/**
 * SuperSoum - Main Entry Point
 * Ouvre directement la page Login si non connecté, sinon Dashboard.
 */

session_start();

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

// ─── ROUTING ──────────────────────────────────────────────────────────────────
$page   = $_GET['page']   ?? '';
$action = $_GET['action'] ?? 'index';

// LOGIN POST HANDLER (avant tout, pour que la redirection fonctionne)
if ($page === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $error    = '';

    $db = Database::getConnection();

    if ($db) {
        // Cherche dans la table admins
        $stmt = $db->prepare("SELECT * FROM admins WHERE username = :u1 OR email = :u2 LIMIT 1");
        $stmt->execute([':u1' => $username, ':u2' => $username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id']        = $admin['id'];
            $_SESSION['admin_username']  = $admin['username'];
            $_SESSION['admin_name']      = $admin['full_name'];
            $_SESSION['admin_role']      = $admin['role'];
            header('Location: index.php?page=dashboard');
            exit;
        } else {
            // Fallback : identifiants en dur (admin / admin123)
            if ($username === 'admin' && $password === 'admin123') {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id']        = 1;
                $_SESSION['admin_username']  = 'admin';
                $_SESSION['admin_name']      = 'Administrateur';
                $_SESSION['admin_role']      = 'superadmin';
                header('Location: index.php?page=dashboard');
                exit;
            }
            $error = 'Identifiant ou mot de passe incorrect.';
        }
    } else {
        // Pas de DB : accepte admin/admin123 directement
        if ($username === 'admin' && $password === 'admin123') {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id']        = 1;
            $_SESSION['admin_username']  = 'admin';
            $_SESSION['admin_name']      = 'Administrateur';
            $_SESSION['admin_role']      = 'superadmin';
            header('Location: index.php?page=dashboard');
            exit;
        }
        $error = 'Identifiant ou mot de passe incorrect.';
    }

    // Réafficher login avec erreur
    require __DIR__ . '/app/views/auth/login.php';
    exit;
}

// LOGOUT
if ($page === 'logout') {
    session_destroy();
    header('Location: index.php');
    exit;
}

// PROTECTION : si pas connecté → login
if (empty($_SESSION['admin_logged_in'])) {
    if ($page !== 'login') {
        require __DIR__ . '/app/views/auth/login.php';
        exit;
    }
    $error = '';
    require __DIR__ . '/app/views/auth/login.php';
    exit;
}

// ─── ZONE PROTÉGÉE (connecté) ─────────────────────────────────────────────────

require_once __DIR__ . '/app/controllers/HomeController.php';
require_once __DIR__ . '/app/controllers/DashboardController.php';
require_once __DIR__ . '/app/controllers/ProductController.php';
require_once __DIR__ . '/app/controllers/CategoryController.php';
require_once __DIR__ . '/app/controllers/BrandController.php';
require_once __DIR__ . '/app/controllers/SupermarketController.php';
require_once __DIR__ . '/app/controllers/PriceController.php';
require_once __DIR__ . '/app/controllers/PromotionController.php';
require_once __DIR__ . '/app/controllers/UserController.php';
require_once __DIR__ . '/app/controllers/StatisticsController.php';
require_once __DIR__ . '/app/controllers/SettingsController.php';

try {
    switch ($page) {

        // Dashboard (page d'accueil admin)
        case '':
        case 'dashboard':
            (new DashboardController())->index();
            break;

        // Comparateur public
        case 'home':
        case 'comparator':
            (new HomeController())->index();
            break;

        // Produits
        case 'products':
            $c = new ProductController();
            match($action) {
                'create' => $c->create(),
                'store'  => $c->store(),
                'show'   => $c->show(),
                'edit'   => $c->edit(),
                'update' => $c->update(),
                'delete' => $c->delete(),
                default  => $c->index(),
            };
            break;

        // Catégories
        case 'categories':
            $c = new CategoryController();
            match($action) {
                'store'              => $c->store(),
                'update'             => $c->update(),
                'delete'             => $c->delete(),
                'subcategory_store'  => $c->subcategoryStore(),
                'subcategory_delete' => $c->subcategoryDelete(),
                default              => $c->index(),
            };
            break;

        // Marques
        case 'brands':
            $c = new BrandController();
            match($action) {
                'store'  => $c->store(),
                'update' => $c->update(),
                'delete' => $c->delete(),
                default  => $c->index(),
            };
            break;

        // Grandes surfaces
        case 'supermarkets':
            $c = new SupermarketController();
            match($action) {
                'store'  => $c->store(),
                'update' => $c->update(),
                'delete' => $c->delete(),
                default  => $c->index(),
            };
            break;

        // Prix
        case 'prices':
            $c = new PriceController();
            match($action) {
                'update' => $c->update(),
                default  => $c->index(),
            };
            break;

        // Promotions
        case 'promotions':
            $c = new PromotionController();
            match($action) {
                'store'  => $c->store(),
                'update' => $c->update(),
                'delete' => $c->delete(),
                default  => $c->index(),
            };
            break;

        // Utilisateurs
        case 'users':
            $c = new UserController();
            match($action) {
                'store'  => $c->store(),
                'update' => $c->update(),
                'delete' => $c->delete(),
                default  => $c->index(),
            };
            break;

        // Statistiques
        case 'statistics':
            (new StatisticsController())->index();
            break;

        // Paramètres
        case 'settings':
            $c = new SettingsController();
            match($action) {
                'update'          => $c->update(),
                'update_profile'  => $c->updateProfile(),
                'update_password' => $c->updatePassword(),
                default           => $c->index(),
            };
            break;

        default:
            (new DashboardController())->index();
            break;
    }

} catch (Throwable $e) {
    echo "<div style='font-family:system-ui;max-width:700px;margin:40px auto;padding:30px;
               background:#fff1f2;border:1px solid #fecdd3;border-radius:12px;color:#9f1239'>
            <h3>Erreur SuperSoum</h3>
            <p>" . htmlspecialchars($e->getMessage()) . "</p>
            <small>" . htmlspecialchars($e->getFile()) . " — ligne " . $e->getLine() . "</small><br><br>
            <a href='index.php?page=dashboard' style='color:#9f1239;font-weight:bold'>← Retour au Dashboard</a>
          </div>";
}
