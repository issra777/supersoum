<?php
/**
 * SuperSoum - Application Configuration
 */

// Enable full error display for debugging
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);



// Set default timezone
date_default_timezone_set('Africa/Tunis');

// Base URL detection
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
$baseUrl = rtrim($protocol . $host . $scriptDir, '/') . '/';

define('BASE_URL', $baseUrl);
define('APP_NAME', 'SuperSoum');
define('APP_TAGLINE', 'Comparateur de Prix Grandes Surfaces Tunisie');
define('APP_VERSION', '1.0.0');

// Paths
define('ROOT_PATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);
define('APP_PATH', ROOT_PATH . 'app' . DIRECTORY_SEPARATOR);
define('PUBLIC_PATH', ROOT_PATH . 'public' . DIRECTORY_SEPARATOR);
define('UPLOADS_PRODUCTS', ROOT_PATH . 'public' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR);

// Currency
define('CURRENCY', 'DT');
define('CURRENCY_DECIMALS', 3);

// Supermarkets supported
define('SUPERMARKETS', [
    'Carrefour' => ['color' => '#004F9F', 'code' => 'carrefour'],
    'Géant'     => ['color' => '#E30613', 'code' => 'geant'],
    'Monoprix'  => ['color' => '#E3001B', 'code' => 'monoprix'],
    'MG'        => ['color' => '#E2001A', 'code' => 'mg'],
    'Aziza'     => ['color' => '#F47B20', 'code' => 'aziza']
]);

// Helper Functions
function formatPrice($price) {
    if ($price === null || $price === '') return '-';
    return number_format((float)$price, 3, '.', ' ') . ' ' . CURRENCY;
}

function sanitize($data) {
    return htmlspecialchars(trim($data ?? ''), ENT_QUOTES, 'UTF-8');
}

function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function redirect($page, $params = []) {
    $url = 'index.php?page=' . urlencode($page);
    if (!empty($params)) {
        foreach ($params as $k => $v) {
            $url .= '&' . urlencode($k) . '=' . urlencode($v);
        }
    }
    header('Location: ' . $url);
    exit;
}

function isLoggedIn(): bool {
    return !empty($_SESSION['admin_logged_in']);
}

function requireAuth(): void {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}
