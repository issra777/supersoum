<?php
/**
 * SuperSoum - Database Connection (PDO)
 * Automatically initializes supersoum_db if not present - Zero manual installation needed
 */

class Database {
    private static ?PDO $instance = null;
    
    private static string $host = '127.0.0.1';
    private static string $port = '3306';
    private static string $db_name = 'supersoum_db';
    private static string $username = 'root';
    private static string $password = '';
    private static string $charset = 'utf8mb4';

    public static function getConnection(): ?PDO {
        if (self::$instance === null) {
            try {
                $dsn = "mysql:host=" . self::$host . ";port=" . self::$port . ";charset=" . self::$charset;
                $pdo = new PDO($dsn, self::$username, self::$password, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);

                // Ensure database exists
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . self::$db_name . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $pdo->exec("USE `" . self::$db_name . "`");

                // Check if tables already exist
                $stmt = $pdo->query("SHOW TABLES LIKE 'products'");
                if ($stmt->rowCount() === 0) {
                    // Automatically load the SQL schema & seed data
                    $sqlFile = ROOT_PATH . 'database' . DIRECTORY_SEPARATOR . 'supersoum_db.sql';
                    if (file_exists($sqlFile)) {
                        $sql = file_get_contents($sqlFile);
                        $pdo->exec($sql);

                        // Ensure admin password is valid
                        $hashed = password_hash('admin123', PASSWORD_DEFAULT);
                        $up = $pdo->prepare("UPDATE admins SET password = ? WHERE username = 'admin'");
                        $up->execute([$hashed]);
                    }
                }

                self::$instance = $pdo;
            } catch (Exception $e) {
                // Try fallback localhost
                try {
                    $pdo = new PDO("mysql:host=localhost;charset=" . self::$charset, self::$username, self::$password, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    ]);
                    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . self::$db_name . "`");
                    $pdo->exec("USE `" . self::$db_name . "`");
                    
                    $stmt = $pdo->query("SHOW TABLES LIKE 'products'");
                    if ($stmt->rowCount() === 0) {
                        $sqlFile = ROOT_PATH . 'database' . DIRECTORY_SEPARATOR . 'supersoum_db.sql';
                        if (file_exists($sqlFile)) {
                            $sql = file_get_contents($sqlFile);
                            $pdo->exec($sql);
                        }
                    }
                    self::$instance = $pdo;
                } catch (Exception $e2) {
                    // Fail gracefully
                    error_log("Database connection error: " . $e2->getMessage());
                }
            }
        }
        return self::$instance;
    }
}
