<?php
/**
 * Product SVG generator for SuperSoum
 */

$products = [
    'eau_safia.svg' => ['Safia', 'EAU MINÉRALE 1.5L', '#0284C7', '#38BDF8', '💧'],
    'eau_sabrine.svg' => ['Sabrine', 'EAU DE SOURCE 1.5L', '#0D9488', '#2DD4BF', '💧'],
    'coca_cola.svg' => ['Coca-Cola', 'ORIGINAL TASTE 1.5L', '#E11D48', '#BE123C', '🥤'],
    'boga_cidre.svg' => ['Boga Cidre', 'LE CIDRE TUNISIEN 1.5L', '#D97706', '#F59E0B', '🍾'],
    'pates_randa.svg' => ['Randa', 'SPAGHETTI N°2 500g', '#D97706', '#B45309', '🍝'],
    'couscous_warda.svg' => ['Warda', 'COUSCOUS FIN 1kg', '#EA580C', '#C2410C', '🌾'],
    'huile_cristal.svg' => ['Cristal', 'HUILE VÉGÉTALE 1L', '#CA8A04', '#EAB308', '🌻'],
    'tomate_sicam.svg' => ['Sicam', 'DOUBLE CONCENTRÉ 800g', '#DC2626', '#991B1B', '🥫'],
    'biscuits_saida.svg' => ['Major Saida', 'GAUFRETTE CHOCOLAT', '#78350F', '#92400E', '🍪'],
    'yaourts_delice.svg' => ['Délice Danone', 'PACK 8 FRAISE', '#DB2777', '#BE185D', '🍓'],
    'fromage_president.svg' => ['Président', 'FROMAGE CARRÉ 24P', '#DC2626', '#1E3A8A', '🧀'],
    'cafe_ben_yedder.svg' => ['Ben Yedder', 'CAFÉ TRADITION 250g', '#451A03', '#78350F', '☕'],
    'lessive_ariel.svg' => ['Ariel', 'LESSIVE POUDRE 3kg', '#15803D', '#0369A1', '🧼'],
    'shampooing_lpm.svg' => ['Le Petit Marseillais', 'SHAMPOING DOUX 250ml', '#D97706', '#F59E0B', '🧴'],
    'dentifrice_signal.svg' => ['Signal', 'WHITE NOW 75ml', '#2563EB', '#1D4ED8', '🪥'],
    'couches_pampers.svg' => ['Pampers', 'MAXI PACK T4 (52)', '#0D9488', '#059669', '👶'],
    'papier_lilies.svg' => ['Lilies', 'PAPIER HYGIÉNIQUE 12R', '#EC4899', '#DB2777', '🧻'],
    'riz_papillon.svg' => ['Papillon', 'RIZ BLANC 1kg', '#0284C7', '#0369A1', '🍚'],
    'placeholder.png' => ['SuperSoum', 'PRODUIT SANS IMAGE', '#64748B', '#94A3B8', '📦']
];

$dir = __DIR__ . DIRECTORY_SEPARATOR;

foreach ($products as $file => $info) {
    list($brand, $desc, $c1, $c2, $emoji) = $info;
    
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
  <defs>
    <linearGradient id="grad_' . md5($file) . '" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="' . $c1 . '"/>
      <stop offset="100%" stop-color="' . $c2 . '"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="#F8FAFC" rx="16"/>
  <rect x="25" y="25" width="150" height="150" rx="12" fill="#FFFFFF" stroke="#E2E8F0" stroke-width="1.5"/>
  <circle cx="100" cy="80" r="36" fill="url(#grad_' . md5($file) . ')" opacity="0.15"/>
  <text x="100" y="92" font-size="34" text-anchor="middle">' . $emoji . '</text>
  <rect x="35" y="125" width="130" height="26" rx="6" fill="url(#grad_' . md5($file) . ')"/>
  <text x="100" y="142" font-family="\'Plus Jakarta Sans\', Arial, sans-serif" font-weight="900" font-size="11" fill="#FFFFFF" text-anchor="middle" letter-spacing="0.02em">' . htmlspecialchars($brand) . '</text>
  <text x="100" y="163" font-family="\'Plus Jakarta Sans\', Arial, sans-serif" font-weight="700" font-size="8" fill="#64748B" text-anchor="middle">' . htmlspecialchars($desc) . '</text>
</svg>';

    file_put_contents($dir . $file, $svg);
}

// Create placeholder.svg
file_put_contents($dir . 'placeholder.svg', file_get_contents($dir . 'placeholder.png'));
echo "All assets generated successfully.\n";
