/**
 * SuperSoum - Main Application JavaScript
 * Rich interactions, Charts and Animations
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Mobile Sidebar Toggle
    const sidebarToggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.app-sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if (sidebarToggleBtn && sidebar) {
        sidebarToggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
            if (overlay) overlay.classList.toggle('show');
        });
    }

    if (overlay) {
        overlay.addEventListener('click', () => {
            if (sidebar) sidebar.classList.remove('show');
            overlay.classList.remove('show');
        });
    }

    // 2. Auto Dismiss Flash Alerts after 5 seconds
    const flashAlerts = document.querySelectorAll('.flash-alert');
    flashAlerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });

    // 3. KPI Animated Counters
    const counters = document.querySelectorAll('.counter-value');
    counters.forEach(counter => {
        const target = parseFloat(counter.getAttribute('data-target') || counter.innerText);
        if (isNaN(target)) return;

        let start = 0;
        const duration = 1000;
        const stepTime = 20;
        const steps = duration / stepTime;
        const increment = target / steps;

        const isDecimal = counter.getAttribute('data-decimal') === 'true';

        const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
                counter.innerText = isDecimal ? target.toFixed(3) : Math.round(target);
                clearInterval(timer);
            } else {
                counter.innerText = isDecimal ? start.toFixed(3) : Math.round(start);
            }
        }, stepTime);
    });

    // 4. Image Preview Handler
    const imageInputs = document.querySelectorAll('.image-upload-input');
    imageInputs.forEach(input => {
        input.addEventListener('change', function() {
            const previewId = this.getAttribute('data-preview');
            const previewEl = document.getElementById(previewId);
            if (previewEl && this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    previewEl.src = e.target.result;
                    previewEl.style.display = 'block';
                };
                reader.readAsDataURL(this.files[0]);
            }
        });
    });

    // 5. Live Promotion Percentage Calculator
    const origPriceInput = document.getElementById('promo_orig_price');
    const promoPriceInput = document.getElementById('promo_new_price');
    const discountInput = document.getElementById('promo_discount_percent');

    if (origPriceInput && promoPriceInput && discountInput) {
        // When promo price changes, calculate discount %
        promoPriceInput.addEventListener('input', () => {
            const orig = parseFloat(origPriceInput.value);
            const promo = parseFloat(promoPriceInput.value);
            if (!isNaN(orig) && !isNaN(promo) && orig > 0 && promo >= 0) {
                const percent = Math.round(((orig - promo) / orig) * 100);
                discountInput.value = Math.max(0, percent);
            }
        });

        // When discount % changes, calculate promo price
        discountInput.addEventListener('input', () => {
            const orig = parseFloat(origPriceInput.value);
            const discount = parseFloat(discountInput.value);
            if (!isNaN(orig) && !isNaN(discount) && orig > 0) {
                const newPrice = orig * (1 - (discount / 100));
                promoPriceInput.value = Math.max(0, newPrice).toFixed(3);
            }
        });

        origPriceInput.addEventListener('input', () => {
            const orig = parseFloat(origPriceInput.value);
            const discount = parseFloat(discountInput.value);
            if (!isNaN(orig) && !isNaN(discount) && discount > 0) {
                const newPrice = orig * (1 - (discount / 100));
                promoPriceInput.value = Math.max(0, newPrice).toFixed(3);
            }
        });
    }

    // 6. Dynamic Best Price Highlighter in Multi-price Form
    const priceInputs = document.querySelectorAll('.multi-market-price-input');
    if (priceInputs.length > 0) {
        const updateBestPriceUI = () => {
            let lowest = Infinity;
            let bestInput = null;

            priceInputs.forEach(inp => {
                const val = parseFloat(inp.value);
                const parentRow = inp.closest('.market-price-row');
                if (parentRow) parentRow.classList.remove('is-cheapest');

                if (!isNaN(val) && val > 0 && val < lowest) {
                    lowest = val;
                    bestInput = inp;
                }
            });

            if (bestInput) {
                const parentRow = bestInput.closest('.market-price-row');
                if (parentRow) parentRow.classList.add('is-cheapest');
            }
        };

        priceInputs.forEach(inp => {
            inp.addEventListener('input', updateBestPriceUI);
        });
        updateBestPriceUI();
    }
});

/**
 * Chart.js Helpers
 */
window.SuperSoumCharts = {
    // Categories Doughnut Chart
    initCategoryChart: (canvasId, labels, data) => {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: [
                        '#16A34A', '#22C55E', '#4ADE80', '#0284C7', 
                        '#38BDF8', '#F59E0B', '#EF4444', '#8B5CF6'
                    ],
                    borderWidth: 2,
                    borderColor: '#FFFFFF'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            font: { family: "'Plus Jakarta Sans', sans-serif", size: 12 }
                        }
                    }
                },
                cutout: '68%'
            }
        });
    },

    // Promotions by Supermarket Bar Chart
    initPromotionsChart: (canvasId, labels, data, colors) => {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Promotions actives',
                    data: data,
                    backgroundColor: colors || '#16A34A',
                    borderRadius: 8,
                    maxBarThickness: 36
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    },

    // Price Evolution Line Chart
    initEvolutionChart: (canvasId, labels, data) => {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Indice Moyen Prix (DT)',
                    data: data,
                    borderColor: '#16A34A',
                    backgroundColor: 'rgba(22, 163, 74, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    pointBackgroundColor: '#16A34A',
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        ticks: {
                            callback: (v) => v.toFixed(2) + ' DT'
                        }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    },

    // Supermarket Comparison Basket Horizontal Bar Chart
    initBasketChart: (canvasId, labels, data, colors) => {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Panier type (10 articles en DT)',
                    data: data,
                    backgroundColor: colors,
                    borderRadius: 8,
                    maxBarThickness: 28
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: (v) => v + ' DT'
                        }
                    },
                    y: {
                        grid: { display: false }
                    }
                }
            }
        });
    }
};
