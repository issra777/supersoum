<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperSoum — Comparez les prix, économisez chaque jour</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- Custom Style for Public Page -->
    <style>
        :root {
            --brand-green: #16A34A;
            --brand-green-hover: #15803D;
            --brand-green-light: #DCFCE7;
            --brand-green-bg: #F0FDF4;
            --text-dark: #0F172A;
            --text-muted: #64748B;
            --bg-page: #F8FAFC;
            --card-border: #E2E8F0;
            --radius-main: 16px;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-page);
            color: var(--text-dark);
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* Top Navbar */
        .ss-navbar {
            background: #ffffff;
            border-bottom: 1px solid var(--card-border);
            padding: 14px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .ss-nav-link {
            color: var(--text-dark);
            font-weight: 600;
            font-size: 14px;
            padding: 6px 14px;
            text-decoration: none;
            transition: color 0.2s;
        }

        .ss-nav-link:hover, .ss-nav-link.active {
            color: var(--brand-green);
        }

        .ss-search-box {
            position: relative;
            max-width: 460px;
            width: 100%;
        }

        .ss-search-input {
            width: 100%;
            padding: 10px 45px 10px 18px;
            border-radius: 50px;
            border: 1px solid #CBD5E1;
            background: #FFFFFF;
            font-size: 14px;
            transition: all 0.2s;
        }

        .ss-search-input:focus {
            outline: none;
            border-color: var(--brand-green);
            box-shadow: 0 0 0 3px rgba(22, 163, 74, 0.15);
        }

        .ss-search-btn {
            position: absolute;
            right: 4px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--brand-green);
            color: white;
            border: none;
            width: 34px;
            height: 34px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.2s;
        }

        .ss-search-btn:hover {
            background: var(--brand-green-hover);
        }

        .btn-auth-pill {
            background: var(--brand-green);
            color: white;
            font-weight: 600;
            font-size: 14px;
            padding: 9px 20px;
            border-radius: 50px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
            border: none;
        }

        .btn-auth-pill:hover {
            background: var(--brand-green-hover);
            color: white;
            box-shadow: 0 4px 12px rgba(22, 163, 74, 0.25);
        }

        /* Hero Section */
        .hero-banner {
            padding: 40px 0 30px;
            background: radial-gradient(circle at 80% 50%, rgba(220, 252, 231, 0.6) 0%, rgba(248, 250, 252, 0) 70%);
        }

        .hero-title {
            font-size: 38px;
            font-weight: 800;
            color: var(--text-dark);
            letter-spacing: -0.5px;
            line-height: 1.2;
        }

        .hero-title span {
            color: var(--brand-green);
        }

        .hero-sub {
            font-size: 16px;
            color: var(--text-muted);
            max-width: 500px;
            margin-bottom: 24px;
        }

        .floating-market-pill {
            background: #ffffff;
            border: 1px solid #E2E8F0;
            border-radius: 50px;
            padding: 6px 14px;
            box-shadow: 0 8px 20px -6px rgba(0, 0, 0, 0.08);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            font-weight: 700;
        }

        /* Main Container Card */
        .comparator-container {
            background: #ffffff;
            border: 1px solid var(--card-border);
            border-radius: 20px;
            box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.05);
            padding: 24px;
            margin-bottom: 40px;
        }

        /* Category Left Menu */
        .category-item-btn {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            border-radius: 12px;
            color: #334155;
            font-weight: 600;
            font-size: 13.5px;
            text-decoration: none;
            transition: all 0.2s;
            margin-bottom: 4px;
        }

        .category-item-btn:hover {
            background-color: #F1F5F9;
            color: var(--brand-green);
        }

        .category-item-btn.active {
            background-color: var(--brand-green-light);
            color: #14532D;
            font-weight: 700;
        }

        /* Result Comparison Card */
        .result-main-card {
            background: #ffffff;
            border: 1px solid #E2E8F0;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.02);
        }

        .market-column-box {
            text-align: center;
            padding: 16px 8px;
            border-radius: 14px;
            border: 1px solid transparent;
            transition: all 0.2s;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .market-column-box.is-cheapest {
            background: #F0FDF4;
            border: 2px solid #86EFAC;
            position: relative;
            box-shadow: 0 10px 25px -5px rgba(22, 163, 74, 0.15);
        }

        .best-price-badge-ribbon {
            background: var(--brand-green);
            color: white;
            font-size: 10px;
            font-weight: 800;
            padding: 3px 8px;
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-top: 6px;
        }

        .market-logo-img {
            max-height: 28px;
            max-width: 90px;
            object-fit: contain;
            margin-bottom: 12px;
        }

        .market-price-tag {
            font-size: 18px;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 2px;
        }

        .market-column-box.is-cheapest .market-price-tag {
            color: #DC2626;
            font-size: 20px;
        }

        .stock-indicator {
            font-size: 11px;
            font-weight: 600;
            color: #16A34A;
        }

        /* Best Price Summary Strip */
        .best-price-strip {
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            border-radius: 12px;
            padding: 16px 20px;
            margin-top: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
        }

        /* Popular Products Small Cards */
        .popular-prod-card {
            background: #FFFFFF;
            border: 1px solid #E2E8F0;
            border-radius: 12px;
            padding: 14px;
            text-align: center;
            transition: all 0.2s;
            text-decoration: none;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .popular-prod-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.08);
            border-color: #86EFAC;
        }

        .btn-compare-mini {
            background: var(--brand-green);
            color: white;
            font-size: 12px;
            font-weight: 700;
            padding: 6px 14px;
            border-radius: 6px;
            border: none;
            margin-top: auto;
            text-decoration: none;
            display: inline-block;
        }

        .btn-compare-mini:hover {
            background: var(--brand-green-hover);
            color: white;
        }

        /* Trust Strip */
        .trust-feature-item {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .trust-icon-circle {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #DCFCE7;
            color: #16A34A;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }
    </style>
</head>
<body>

<!-- 1. Top Navigation Bar (Screenshot Style) -->
<nav class="ss-navbar">
    <div class="container-xl">
        <div class="d-flex align-items-center justify-content-between gap-3">
            <!-- Brand Logo -->
            <a href="index.php" class="d-flex align-items-center gap-2 text-decoration-none">
                <div style="background: #16A34A; color: white; width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 20px;">
                    <i class="bi bi-cart3"></i>
                </div>
                <div>
                    <span class="fs-4 fw-black text-dark" style="letter-spacing: -0.5px;">Super<span style="color:#16A34A;">Soum</span></span>
                    <div style="font-size: 9px; color: #64748B; font-weight: 600; margin-top: -3px;">Trouvez mieux, payez moins</div>
                </div>
            </a>

            <!-- Search Bar in Header -->
            <form action="index.php" method="GET" class="ss-search-box d-none d-md-block">
                <input type="text" name="search" class="ss-search-input" placeholder="Rechercher un produit (ex : lait, sucre, huile...)" value="<?= sanitize($search) ?>">
                <button type="submit" class="ss-search-btn" title="Rechercher">
                    <i class="bi bi-search"></i>
                </button>
            </form>

            <!-- Nav Links -->
            <div class="d-flex align-items-center gap-2">
                <a href="index.php" class="ss-nav-link active d-none d-lg-inline">Accueil</a>
                <a href="#categoriesSection" class="ss-nav-link d-none d-lg-inline">Catégories</a>
                <a href="#comparatorSection" class="ss-nav-link d-none d-lg-inline">Comparateur</a>
                
                <a href="#" class="ss-nav-link d-inline-flex align-items-center gap-1" id="favoritesBtn" title="Vos Favoris">
                    <i class="bi bi-heart"></i>
                    <span class="d-none d-sm-inline">Favoris</span>
                    <span class="badge bg-danger rounded-pill" id="favCount" style="font-size: 10px; display:none;">0</span>
                </a>

                <!-- Admin Link / Login -->
                <?php if (isLoggedIn()): ?>
                    <a href="index.php?page=dashboard" class="btn-auth-pill">
                        <i class="bi bi-speedometer2"></i>
                        <span>Admin</span>
                    </a>
                <?php else: ?>
                    <a href="index.php?page=login" class="btn-auth-pill">
                        <i class="bi bi-person-circle"></i>
                        <span>Se connecter</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- 2. Hero Section (Exact matching visual from Screenshot 1) -->
<section class="hero-banner">
    <div class="container-xl">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <h1 class="hero-title mb-3">
                    Comparez les prix,<br>
                    <span>économisez chaque jour</span>
                </h1>
                <p class="hero-sub">
                    SuperSoum vous aide à trouver les meilleurs prix chez vos magasins préférés en Tunisie.
                </p>
                <div class="d-flex align-items-center gap-3">
                    <a href="#comparatorSection" class="btn btn-auth-pill py-3 px-4 fs-6">
                        Commencer &rarr;
                    </a>
                    <a href="index.php?page=promotions" class="btn btn-light border py-3 px-4 fw-bold text-dark rounded-pill">
                        Voir les offres
                    </a>
                </div>
            </div>

            <!-- Floating Supermarkets Graphic -->
            <div class="col-lg-6 text-center position-relative">
                <div style="max-width: 480px; margin: 0 auto; position: relative;">
                    <!-- Main Basket Visual -->
                    <div style="background: white; border-radius: 30px; padding: 24px; box-shadow: 0 20px 40px -10px rgba(22, 163, 74, 0.15); border: 1px solid #E2E8F0;">
                        <img src="public/images/products/lait_delice.svg" alt="Panier" style="height: 160px; object-fit: contain;">
                        <div class="mt-3 fw-bold text-dark fs-5">Panier Économique Tunisie</div>
                        <span class="badge bg-success bg-opacity-10 text-success fw-bold px-3 py-1">Prix vérifiés en temps réel</span>
                    </div>

                    <!-- Floating Market Badges around basket -->
                    <div class="position-absolute" style="top: -10px; left: -15px;">
                        <div class="floating-market-pill">
                            <img src="public/images/supermarkets/carrefour.svg" alt="" style="height: 14px;">
                            <span class="text-primary">1.350 DT</span>
                        </div>
                    </div>
                    <div class="position-absolute" style="top: 15px; right: -15px;">
                        <div class="floating-market-pill">
                            <img src="public/images/supermarkets/mg.svg" alt="" style="height: 14px;">
                            <span class="text-danger">1.320 DT</span>
                        </div>
                    </div>
                    <div class="position-absolute" style="bottom: 30px; left: -25px;">
                        <div class="floating-market-pill">
                            <img src="public/images/supermarkets/geant.svg" alt="" style="height: 14px;">
                            <span style="color:#E30613;">1.350 DT</span>
                        </div>
                    </div>
                    <div class="position-absolute" style="bottom: 10px; right: -20px;">
                        <div class="floating-market-pill" style="border: 2px solid #86EFAC; background: #F0FDF4;">
                            <img src="public/images/supermarkets/aziza.svg" alt="" style="height: 14px;">
                            <span class="text-success fw-black">1.290 DT ★</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 3. Main Comparator Section (Screenshot 2: Sidebar Categories + 5 Market Cards + Popular Grid) -->
<section class="py-4" id="comparatorSection">
    <div class="container-xl">
        <div class="comparator-container">
            <div class="row g-4">
                
                <!-- Left Sidebar Categories -->
                <div class="col-lg-3 col-md-4" id="categoriesSection">
                    <div class="fw-bold text-dark fs-6 mb-3 px-2">Catégories</div>
                    
                    <div class="d-flex flex-column">
                        <a href="index.php" class="category-item-btn <?= empty($categoryId) ? 'active' : '' ?>">
                            <i class="bi bi-grid-fill text-success"></i>
                            <span>Tous les produits</span>
                        </a>

                        <?php 
                        $quickCategories = [
                            3  => ['Produits laitiers', 'bi-egg'],
                            8  => ['Épicerie sucrée & salée', 'bi-cart4'],
                            2  => ['Boissons', 'bi-cup-straw'],
                            10 => ['Hygiène & beauté', 'bi-person-heart'],
                            11 => ['Entretien maison', 'bi-droplet-half'],
                            12 => ['Bébé', 'bi-emoji-smile'],
                            7  => ['Surgelés', 'bi-snow'],
                        ];

                        foreach ($quickCategories as $cId => $cMeta): 
                        ?>
                            <a href="index.php?category=<?= $cId ?>" class="category-item-btn <?= ($categoryId == $cId) ? 'active' : '' ?>">
                                <i class="bi <?= $cMeta[1] ?>"></i>
                                <span><?= $cMeta[0] ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>

                    <!-- Left Goal Box (Screenshot 2) -->
                    <div class="p-3 mt-4 rounded-3 border bg-light text-start">
                        <div class="fw-bold text-dark small mb-1">
                            <i class="bi bi-star-fill text-success me-1"></i> Notre objectif
                        </div>
                        <p class="text-muted small mb-0" style="font-size: 11.5px; line-height: 1.4;">
                            Vous aider à trouver les meilleurs prix facilement et rapidement chez toutes les enseignes.
                        </p>
                    </div>
                </div>

                <!-- Right Main Comparison Area -->
                <div class="col-lg-9 col-md-8">
                    
                    <!-- Result Box for Active Product -->
                    <div class="result-main-card mb-4">
                        <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
                            <h3 class="fw-bold text-dark fs-5 mb-0">
                                Résultat pour : <span class="text-success"><?= sanitize($selectedProduct['name'] ?? 'Lait 1L') ?></span>
                            </h3>
                            <div class="d-flex align-items-center gap-2">
                                <span class="text-muted small">
                                    Aujourd'hui : <strong><?= date('d M Y') ?></strong>
                                </span>
                                <a href="index.php?page=prices" class="btn btn-sm btn-brand-outline rounded-pill" style="font-size: 12px;">
                                    <i class="bi bi-sliders me-1"></i> Modifier les magasins
                                </a>
                            </div>
                        </div>

                        <!-- 5 Columns Comparison Grid (Screenshot 2) -->
                        <div class="row g-2 align-items-stretch">
                            <!-- Product thumbnail column -->
                            <div class="col-lg-2 col-6 text-center d-flex flex-column justify-content-center p-2 border rounded-3 bg-light">
                                <img src="public/images/products/<?= sanitize($selectedProduct['image'] ?? 'placeholder.png') ?>" alt="" style="height: 70px; object-fit: contain; margin: 0 auto 6px;" onerror="this.onerror=null; this.src='public/images/products/placeholder.png';">
                                <div class="fw-bold text-dark small text-truncate"><?= sanitize($selectedProduct['name'] ?? 'Produit') ?></div>
                                <div class="text-muted" style="font-size: 10px;"><?= sanitize($selectedProduct['unit'] ?? '1 litre') ?></div>
                            </div>

                            <!-- 5 Supermarket Columns -->
                            <?php foreach ($supermarkets as $market): ?>
                                <?php 
                                    $mPriceData = $selectedPrices[$market['id']] ?? null;
                                    $priceVal = $mPriceData ? (float)$mPriceData['effective_price'] : null;
                                    $isCheapest = ($minPrice !== null && $priceVal !== null && $priceVal == $minPrice);
                                ?>
                                <div class="col-lg-2 col-6">
                                    <div class="market-column-box <?= $isCheapest ? 'is-cheapest' : 'bg-light' ?>">
                                        <img src="public/images/supermarkets/<?= sanitize($market['logo']) ?>" alt="<?= sanitize($market['name']) ?>" class="market-logo-img">
                                        
                                        <div class="market-price-tag">
                                            <?= $priceVal !== null ? number_format($priceVal, 3, ',', ' ') . ' DT' : '—' ?>
                                        </div>

                                        <div class="stock-indicator">
                                            <i class="bi bi-check2"></i> En stock
                                        </div>

                                        <?php if ($isCheapest): ?>
                                            <div class="best-price-badge-ribbon">
                                                <i class="bi bi-trophy-fill"></i> Meilleur prix
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Best Price Banner Strip (Screenshot 2) -->
                        <div class="best-price-strip">
                            <div class="d-flex align-items-center gap-3">
                                <div class="fs-4">🏆</div>
                                <div>
                                    <div class="fw-bold text-dark">
                                        Meilleur prix : <span class="text-success"><?= sanitize($bestMarket ?? 'Aziza') ?></span> <span class="badge bg-success ms-1"><?= formatPrice($minPrice) ?></span>
                                    </div>
                                    <?php if ($savings > 0): ?>
                                        <div class="small text-muted">
                                            Économisez jusqu'à <strong class="text-danger"><?= number_format($savings, 3, ',', ' ') ?> DT</strong> par rapport au prix le plus élevé.
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <button type="button" class="btn btn-outline-success btn-sm rounded-pill px-3 fw-semibold add-to-fav-btn" data-name="<?= sanitize($selectedProduct['name']) ?>">
                                <i class="bi bi-heart me-1"></i> Ajouter aux favoris
                            </button>
                        </div>
                    </div>

                    <!-- Popular Products Quick Cards (Screenshot 2) -->
                    <div class="d-flex align-items-center justify-content-between mb-3 mt-4">
                        <h4 class="fw-bold text-dark fs-6 mb-0">Produits populaires</h4>
                        <a href="index.php?page=products" class="small text-success fw-bold text-decoration-none">Voir plus de produits &rarr;</a>
                    </div>

                    <div class="row g-3">
                        <?php foreach (array_slice($popularProducts, 0, 6) as $pop): ?>
                            <?php 
                                $popMin = null;
                                if (!empty($pop['prices'])) {
                                    foreach ($pop['prices'] as $pr) {
                                        if ($pr['effective_price'] !== null) {
                                            $eff = (float)$pr['effective_price'];
                                            if ($popMin === null || $eff < $popMin) $popMin = $eff;
                                        }
                                    }
                                }
                            ?>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                <a href="index.php?product_id=<?= $pop['id'] ?>#comparatorSection" class="popular-prod-card text-decoration-none">
                                    <img src="public/images/products/<?= sanitize($pop['image']) ?>" alt="" style="height: 60px; object-fit: contain; margin: 0 auto 8px;" onerror="this.onerror=null; this.src='public/images/products/placeholder.png';">
                                    <div class="fw-bold text-dark small text-truncate" title="<?= sanitize($pop['name']) ?>"><?= sanitize($pop['name']) ?></div>
                                    <div class="text-muted" style="font-size: 10px;"><?= sanitize($pop['unit']) ?></div>
                                    <div class="text-muted small mt-1" style="font-size: 11px;">À partir de</div>
                                    <div class="fw-black text-dark mb-2" style="font-size: 13px;">
                                        <?= $popMin !== null ? number_format($popMin, 3, ',', ' ') . ' DT' : '—' ?>
                                    </div>
                                    <span class="btn-compare-mini">Comparer</span>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- 4. Bottom Trust & Feature Strip (Exact from Screenshot 1 & 2) -->
<footer class="bg-white border-top py-4">
    <div class="container-xl">
        <div class="row g-4 text-center text-md-start">
            <div class="col-lg-3 col-md-6">
                <div class="trust-feature-item">
                    <div class="trust-icon-circle"><i class="bi bi-clock-history"></i></div>
                    <div>
                        <div class="fw-bold text-dark small">Prix mis à jour chaque jour</div>
                        <div class="text-muted" style="font-size: 11px;">Données fiables et vérifiées</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="trust-feature-item">
                    <div class="trust-icon-circle"><i class="bi bi-arrow-repeat"></i></div>
                    <div>
                        <div class="fw-bold text-dark small">Comparez facilement</div>
                        <div class="text-muted" style="font-size: 11px;">Plusieurs magasins en un seul clic</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="trust-feature-item">
                    <div class="trust-icon-circle"><i class="bi bi-piggy-bank"></i></div>
                    <div>
                        <div class="fw-bold text-dark small">Économisez plus</div>
                        <div class="text-muted" style="font-size: 11px;">Trouvez toujours le meilleur prix</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="trust-feature-item">
                    <div class="trust-icon-circle"><i class="bi bi-shield-check"></i></div>
                    <div>
                        <div class="fw-bold text-dark small">100% Gratuit</div>
                        <div class="text-muted" style="font-size: 11px;">Aucun frais, aucun abonnement</div>
                    </div>
                </div>
            </div>
        </div>

        <hr class="my-4">

        <div class="d-flex flex-wrap align-items-center justify-content-between text-muted small">
            <div>
                &copy; <?= date('Y') ?> <strong>SuperSoum</strong> — Le 1er comparateur de prix des grandes surfaces en Tunisie.
            </div>
            <div class="d-flex gap-3">
                <a href="index.php?page=login" class="text-decoration-none text-muted">Espace Administration</a>
            </div>
        </div>
    </div>
</footer>

<!-- Simple Favorites Handler -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    let favs = JSON.parse(localStorage.getItem('supersoum_favs') || '[]');
    const countBadge = document.getElementById('favCount');

    const updateFavUI = () => {
        if (favs.length > 0) {
            countBadge.innerText = favs.length;
            countBadge.style.display = 'inline-block';
        } else {
            countBadge.style.display = 'none';
        }
    };
    updateFavUI();

    document.querySelectorAll('.add-to-fav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const name = this.getAttribute('data-name');
            if (!favs.includes(name)) {
                favs.push(name);
                localStorage.setItem('supersoum_favs', JSON.stringify(favs));
                this.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i> Ajouté aux favoris';
                this.classList.replace('btn-outline-success', 'btn-success');
                updateFavUI();
            } else {
                alert('Ce produit est déjà dans vos favoris.');
            }
        });
    });
});
</script>

</body>
</html>
