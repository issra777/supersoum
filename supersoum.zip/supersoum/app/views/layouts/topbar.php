<?php
/**
 * Topbar Layout
 */
$searchQuery = $_GET['search'] ?? '';
?>
<header class="app-topbar">
    <div class="d-flex align-items-center gap-3">
        <button type="button" class="btn btn-light d-lg-none p-2 rounded-2 border" id="sidebarToggle" aria-label="Toggle Navigation">
            <i class="bi bi-list fs-5"></i>
        </button>

        <!-- Global Search -->
        <form action="index.php" method="GET" class="topbar-search-form">
            <input type="hidden" name="page" value="products">
            <i class="bi bi-search topbar-search-icon"></i>
            <input type="text" name="search" class="topbar-search-input" placeholder="Rechercher produit, code-barres, marque..." value="<?= sanitize($searchQuery) ?>">
        </form>
    </div>

    <div class="topbar-actions">
        <!-- Quick Action Add Product -->
        <a href="index.php?page=products&action=create" class="btn btn-brand btn-sm d-none d-sm-inline-flex">
            <i class="bi bi-plus-lg"></i>
            <span>Nouveau Produit</span>
        </a>

        <!-- Notifications Dropdown Simulation -->
        <div class="dropdown">
            <button class="btn btn-light rounded-circle p-2 border position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-bell text-secondary"></i>
                <span class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle">
                    <span class="visually-hidden">Alertes</span>
                </span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 p-2 mt-2" style="width: 290px; border-radius: 12px;">
                <li class="p-2 border-bottom fw-bold text-dark small d-flex justify-content-between">
                    <span>Notifications</span>
                    <span class="badge bg-success bg-opacity-10 text-success">8 promos</span>
                </li>
                <li><a class="dropdown-item py-2 small rounded" href="index.php?page=promotions"><i class="bi bi-tag-fill text-danger me-2"></i> Promo Ariel expire dans 12j</a></li>
                <li><a class="dropdown-item py-2 small rounded" href="index.php?page=promotions"><i class="bi bi-tag-fill text-warning me-2"></i> Promo Pampers expire dans 7j</a></li>
                <li><a class="dropdown-item py-2 small rounded" href="index.php?page=prices"><i class="bi bi-arrow-repeat text-success me-2"></i> 20 prix synchronisés</a></li>
            </ul>
        </div>

        <!-- Admin Profile Menu -->
        <div class="dropdown">
            <button class="btn btn-light rounded-pill p-1 pe-3 border d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="admin-avatar" style="width: 28px; height: 28px; font-size: 12px;">
                    <?= strtoupper(substr($_SESSION['admin_name'] ?? 'A', 0, 1)) ?>
                </div>
                <span class="fw-semibold small d-none d-md-inline text-dark"><?= sanitize($_SESSION['admin_name'] ?? 'Admin') ?></span>
                <i class="bi bi-chevron-down text-muted small"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 p-2 mt-2" style="border-radius: 12px;">
                <li><a class="dropdown-item py-2 rounded small" href="index.php?page=settings"><i class="bi bi-person-gear me-2 text-primary"></i> Mon Profil</a></li>
                <li><a class="dropdown-item py-2 rounded small" href="index.php?page=settings"><i class="bi bi-sliders me-2 text-primary"></i> Paramètres</a></li>
                <li><hr class="dropdown-divider my-1"></li>
                <li><a class="dropdown-item py-2 rounded small text-danger" href="index.php?page=logout"><i class="bi bi-box-arrow-right me-2"></i> Déconnexion</a></li>
            </ul>
        </div>
    </div>
</header>
