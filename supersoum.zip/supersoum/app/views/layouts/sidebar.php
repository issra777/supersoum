<?php
/**
 * Sidebar Navigation
 */
$currentPage = $_GET['page'] ?? 'dashboard';
?>
<aside class="app-sidebar">
    <!-- Brand Header -->
    <div class="sidebar-header">
        <a href="index.php?page=dashboard" class="brand-logo-wrap">
            <div class="brand-icon">
                <i class="bi bi-cart3"></i>
            </div>
            <div>
                <h1 class="brand-title">Super<span>Soum</span></h1>
                <p class="brand-tagline">COMPARATEUR PRIX</p>
            </div>
        </a>
    </div>

    <!-- Navigation Links -->
    <div class="sidebar-nav">
        <div class="nav-category-title">Vue Générale</div>
        
        <a href="index.php?page=dashboard" class="nav-link-custom <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
            <i class="bi bi-grid-1x2-fill"></i>
            <span>Tableau de bord</span>
        </a>

        <a href="index.php?page=home" class="nav-link-custom <?= $currentPage === 'home' ? 'active' : '' ?>">
            <i class="bi bi-shop"></i>
            <span>Vue Comparateur Public</span>
        </a>

        <div class="nav-category-title">Catalogue & Prix</div>

        <a href="index.php?page=products" class="nav-link-custom <?= $currentPage === 'products' ? 'active' : '' ?>">
            <i class="bi bi-box-seam-fill"></i>
            <span>Produits</span>
        </a>

        <a href="index.php?page=prices" class="nav-link-custom <?= $currentPage === 'prices' ? 'active' : '' ?>">
            <i class="bi bi-tags-fill"></i>
            <span>Comparateur Prix</span>
        </a>

        <a href="index.php?page=promotions" class="nav-link-custom <?= $currentPage === 'promotions' ? 'active' : '' ?>">
            <i class="bi bi-percent"></i>
            <span>Promotions</span>
        </a>

        <div class="nav-category-title">Classification</div>

        <a href="index.php?page=categories" class="nav-link-custom <?= $currentPage === 'categories' ? 'active' : '' ?>">
            <i class="bi bi-diagram-3-fill"></i>
            <span>Catégories</span>
        </a>

        <a href="index.php?page=brands" class="nav-link-custom <?= $currentPage === 'brands' ? 'active' : '' ?>">
            <i class="bi bi-bookmark-star-fill"></i>
            <span>Marques</span>
        </a>

        <a href="index.php?page=supermarkets" class="nav-link-custom <?= $currentPage === 'supermarkets' ? 'active' : '' ?>">
            <i class="bi bi-shop-window"></i>
            <span>Grandes Surfaces</span>
        </a>

        <div class="nav-category-title">Gestion & Système</div>

        <a href="index.php?page=users" class="nav-link-custom <?= $currentPage === 'users' ? 'active' : '' ?>">
            <i class="bi bi-people-fill"></i>
            <span>Utilisateurs</span>
        </a>

        <a href="index.php?page=statistics" class="nav-link-custom <?= $currentPage === 'statistics' ? 'active' : '' ?>">
            <i class="bi bi-bar-chart-line-fill"></i>
            <span>Statistiques</span>
        </a>

        <a href="index.php?page=settings" class="nav-link-custom <?= $currentPage === 'settings' ? 'active' : '' ?>">
            <i class="bi bi-gear-fill"></i>
            <span>Paramètres</span>
        </a>
    </div>

    <!-- Admin Footer -->
    <div class="sidebar-footer">
        <div class="admin-profile-pill">
            <div class="admin-avatar">
                <?= strtoupper(substr($_SESSION['admin_name'] ?? 'A', 0, 1)) ?>
            </div>
            <div style="line-height:1.2;">
                <div class="text-white fw-bold small"><?= sanitize($_SESSION['admin_name'] ?? 'Admin') ?></div>
                <div class="text-muted" style="font-size:10px;">SuperAdmin</div>
            </div>
        </div>
        <a href="index.php?page=logout" class="text-secondary hover-text-danger p-2 rounded" title="Se déconnecter" onclick="return confirm('Voulez-vous vraiment vous déconnecter ?');">
            <i class="bi bi-box-arrow-right fs-5 text-danger"></i>
        </a>
    </div>
</aside>
