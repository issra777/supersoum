<?php
/**
 * Layout Header
 */
$currentPage = $_GET['page'] ?? 'dashboard';
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize(APP_NAME) ?> — Administration & Comparateur de Prix</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>
    
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="public/css/style.css?v=<?= APP_VERSION ?>">
</head>
<body>

<div class="app-wrapper">
    <!-- Sidebar Overlay for mobile -->
    <div id="sidebarOverlay" class="d-lg-none" style="position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:999; display:none;"></div>
    
    <!-- Sidebar -->
    <?php require_once APP_PATH . 'views/layouts/sidebar.php'; ?>

    <!-- Main Wrapper -->
    <div class="app-main">
        <!-- Topbar -->
        <?php require_once APP_PATH . 'views/layouts/topbar.php'; ?>

        <!-- Content Area -->
        <main class="app-content">
            <?php if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] === 'danger' ? 'danger' : ($flash['type'] === 'warning' ? 'warning' : ($flash['type'] === 'info' ? 'info' : 'success')) ?> flash-alert alert-dismissible fade show" role="alert">
                    <div class="d-flex align-items-center gap-2">
                        <i class="bi <?= $flash['type'] === 'danger' ? 'bi-exclamation-octagon-fill' : ($flash['type'] === 'warning' ? 'bi-exclamation-triangle-fill' : ($flash['type'] === 'info' ? 'bi-info-circle-fill' : 'bi-check-circle-fill')) ?> fs-5"></i>
                        <div><?= $flash['message'] ?></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
                </div>
            <?php endif; ?>
