<?php
/**
 * Layout Footer
 */
?>
        </main>

        <!-- Footer Bar -->
        <footer class="py-3 px-4 border-top bg-white text-muted small d-flex flex-wrap justify-content-between align-items-center mt-auto">
            <div>
                &copy; <?= date('Y') ?> <strong class="text-dark">SuperSoum</strong> — Le 1er comparateur de prix des grandes surfaces en Tunisie.
            </div>
            <div class="d-flex align-items-center gap-3">
                <span class="badge bg-success bg-opacity-10 text-success fw-bold px-2 py-1"><i class="bi bi-shield-check me-1"></i> Système Actif</span>
                <span class="text-secondary">v<?= APP_VERSION ?></span>
            </div>
        </footer>
    </div>
</div>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom App JS -->
<script src="public/js/app.js?v=<?= APP_VERSION ?>"></script>

</body>
</html>
