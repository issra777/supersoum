<?php
/**
 * Users View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Gestion des Utilisateurs</h1>
        <p class="page-subtitle">Comptes consommateurs enregistrés sur le comparateur SuperSoum.</p>
    </div>
    <div class="d-flex gap-2">
        <button type="button" class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="bi bi-person-plus-fill me-1"></i> Nouvel Utilisateur
        </button>
    </div>
</div>

<div class="custom-card">
    <div class="custom-card-header">
        <h3 class="custom-card-title">
            <i class="bi bi-people-fill text-success"></i>
            <span>Liste des Utilisateurs Inscrits</span>
        </h3>
        <span class="badge bg-light text-dark border fw-bold"><?= count($users) ?> comptes</span>
    </div>
    <div class="table-responsive">
        <table class="comparison-table">
            <thead>
                <tr>
                    <th>Utilisateur</th>
                    <th>Téléphone</th>
                    <th>Gouvernorat</th>
                    <th>Statut</th>
                    <th>Date d'inscription</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr><td colspan="6" class="text-center py-4 text-muted">Aucun utilisateur enregistré.</td></tr>
                <?php else: ?>
                    <?php foreach ($users as $u): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <div class="admin-avatar" style="width: 38px; height: 38px; font-size: 14px; background: #0F172A;">
                                        <?= strtoupper(substr($u['name'], 0, 1)) ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark"><?= sanitize($u['name']) ?></div>
                                        <div class="small text-muted"><?= sanitize($u['email']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td><?= sanitize($u['phone'] ?: 'Non renseigné') ?></td>
                            <td>
                                <span class="badge bg-light text-secondary border">
                                    <i class="bi bi-geo-alt-fill text-danger me-1"></i> <?= sanitize($u['governorate']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($u['status'] === 'active'): ?>
                                    <span class="badge bg-success bg-opacity-10 text-success"><i class="bi bi-check-circle me-1"></i> Actif</span>
                                <?php else: ?>
                                    <span class="badge bg-danger bg-opacity-10 text-danger"><i class="bi bi-x-circle me-1"></i> Inactif</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-muted small"><?= date('d/m/Y', strtotime($u['registered_at'])) ?></td>
                            <td class="text-center">
                                <div class="d-flex justify-content-center gap-1">
                                    <button class="btn btn-sm btn-light border text-primary" data-bs-toggle="modal" data-bs-target="#editUserModal<?= $u['id'] ?>">
                                        <i class="bi bi-pencil-fill"></i>
                                    </button>
                                    <form action="index.php?page=users&action=delete" method="POST" class="d-inline" onsubmit="return confirm('Supprimer cet utilisateur ?');">
                                        <input type="hidden" name="id" value="<?= $u['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-light border text-danger">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>

                        <!-- Edit User Modal -->
                        <div class="modal fade" id="editUserModal<?= $u['id'] ?>" tabindex="-1">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content border-0 shadow-lg rounded-4">
                                    <form action="index.php?page=users&action=update" method="POST">
                                        <input type="hidden" name="id" value="<?= $u['id'] ?>">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold">Modifier Utilisateur</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label small fw-bold">Nom complet</label>
                                                <input type="text" name="name" class="form-control" value="<?= sanitize($u['name']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label small fw-bold">Email</label>
                                                <input type="email" name="email" class="form-control" value="<?= sanitize($u['email']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label small fw-bold">Téléphone</label>
                                                <input type="text" name="phone" class="form-control" value="<?= sanitize($u['phone'] ?? '') ?>">
                                            </div>
                                            <div class="row g-2 mb-3">
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">Gouvernorat</label>
                                                    <select name="governorate" class="form-select">
                                                        <?php 
                                                        $govs = ['Tunis', 'Ariana', 'Ben Arous', 'Manouba', 'Nabeul', 'Sousse', 'Monastir', 'Sfax', 'Bizerte'];
                                                        foreach ($govs as $g): ?>
                                                            <option value="<?= $g ?>" <?= ($u['governorate'] === $g) ? 'selected' : '' ?>><?= $g ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">Statut</label>
                                                    <select name="status" class="form-select">
                                                        <option value="active" <?= ($u['status'] === 'active') ? 'selected' : '' ?>>Actif</option>
                                                        <option value="inactive" <?= ($u['status'] === 'inactive') ? 'selected' : '' ?>>Inactif</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                                            <button type="submit" class="btn btn-brand">Enregistrer</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form action="index.php?page=users&action=store" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Nouvel Utilisateur</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nom complet <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="Ex: Anis Dridi" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Adresse Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control" placeholder="anis@example.tn" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Numéro de téléphone</label>
                        <input type="text" name="phone" class="form-control" placeholder="+216 98 000 000">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Gouvernorat</label>
                        <select name="governorate" class="form-select">
                            <option value="Tunis">Tunis</option>
                            <option value="Ariana">Ariana</option>
                            <option value="Ben Arous">Ben Arous</option>
                            <option value="Manouba">Manouba</option>
                            <option value="Nabeul">Nabeul</option>
                            <option value="Sousse">Sousse</option>
                            <option value="Sfax">Sfax</option>
                            <option value="Bizerte">Bizerte</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-brand">Créer le compte</button>
                </div>
            </form>
        </div>
    </div>
</div>
