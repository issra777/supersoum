<?php
/**
 * Product Detailed Comparison View
 */
?>

<div class="page-header">
    <div class="d-flex align-items-center gap-3">
        <a href="index.php?page=products" class="btn btn-light border p-2 rounded-3" title="Retour aux produits">
            <i class="bi bi-arrow-left fs-5"></i>
        </a>
        <div>
            <h1 class="page-title"><?= sanitize($product['name']) ?></h1>
            <p class="page-subtitle">Comparaison détaillée des prix dans les 5 grandes surfaces tunisiennes.</p>
        </div>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="index.php?page=products&action=edit&id=<?= $product['id'] ?>" class="btn btn-brand-outline">
            <i class="bi bi-pencil-fill me-1"></i> Modifier le produit
        </a>
        <a href="index.php?page=promotions" class="btn btn-brand">
            <i class="bi bi-percent me-1"></i> Gérer promotions
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Left Column: Product Info Card -->
    <div class="col-lg-4">
        <div class="custom-card mb-4">
            <div class="product-image-container" style="height: 240px;">
                <img src="public/images/products/<?= sanitize($product['image']) ?>" 
                     alt="<?= sanitize($product['name']) ?>" 
                     class="product-img" 
                     style="max-height: 190px;"
                     onerror="this.onerror=null; this.src='public/images/products/placeholder.png';">
            </div>
            <div class="custom-card-body">
                <div class="mb-3">
                    <span class="badge bg-success bg-opacity-10 text-success fw-bold px-3 py-1 mb-2">
                        <?= sanitize($product['category_name'] ?? 'Non classé') ?>
                    </span>
                    <h3 class="fw-bold text-dark fs-4 mb-1"><?= sanitize($product['name']) ?></h3>
                    <p class="text-muted small"><?= sanitize($product['description'] ?: 'Aucune description disponible pour ce produit.') ?></p>
                </div>

                <hr class="my-3">

                <ul class="list-unstyled mb-0 d-flex flex-column gap-2 small">
                    <li class="d-flex justify-content-between">
                        <span class="text-muted">Marque :</span>
                        <strong class="text-dark"><?= sanitize($product['brand_name'] ?? 'Générique') ?></strong>
                    </li>
                    <li class="d-flex justify-content-between">
                        <span class="text-muted">Conditionnement / Unité :</span>
                        <strong class="text-dark"><?= sanitize($product['unit']) ?></strong>
                    </li>
                    <li class="d-flex justify-content-between">
                        <span class="text-muted">Code-barres (EAN) :</span>
                        <code><?= sanitize($product['barcode'] ?: 'Non renseigné') ?></code>
                    </li>
                    <li class="d-flex justify-content-between">
                        <span class="text-muted">Statut :</span>
                        <span class="badge bg-success"><?= ucfirst($product['status']) ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Right Column: Supermarket Comparison Matrix -->
    <div class="col-lg-8">
        <div class="custom-card mb-4">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-tag-fill text-success"></i>
                    <span>Comparatif par Enseigne</span>
                </h3>
                <span class="badge bg-success bg-opacity-10 text-success fw-bold px-3 py-2">
                    <i class="bi bi-shield-check me-1"></i> Prix vérifiés
                </span>
            </div>
            <div class="table-responsive">
                <table class="comparison-table">
                    <thead>
                        <tr>
                            <th>Grande Surface</th>
                            <th>Prix Régulier</th>
                            <th>Offre Promo</th>
                            <th>Prix Applicable</th>
                            <th>Écart / Meilleur Prix</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($prices)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">
                                    Aucun prix enregistré. <a href="index.php?page=products&action=edit&id=<?= $product['id'] ?>">Renseigner les prix</a>.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($prices as $item): ?>
                                <tr class="<?= $item['is_best_price'] ? 'best-price-row' : '' ?>">
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="badge px-3 py-2 rounded-2 fw-bold" style="background-color: <?= $item['color_hex'] ?>15; color: <?= $item['color_hex'] ?>; border: 1px solid <?= $item['color_hex'] ?>40;">
                                                <?= sanitize($item['supermarket_name']) ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="text-muted <?= ($item['promo_id'] && $item['promo_active']) ? 'text-decoration-line-through' : 'fw-bold text-dark' ?>">
                                            <?= formatPrice($item['regular_price']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($item['promo_id'] && $item['promo_active']): ?>
                                            <div class="d-flex align-items-center gap-1">
                                                <span class="badge-promo">-<?= $item['discount_percentage'] ?>%</span>
                                                <span class="fw-bold text-danger"><?= formatPrice($item['promo_price']) ?></span>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong class="fs-5 <?= $item['is_best_price'] ? 'text-success' : 'text-dark' ?>">
                                            <?= formatPrice($item['effective_price']) ?>
                                        </strong>
                                    </td>
                                    <td>
                                        <?php if ($item['is_best_price']): ?>
                                            <span class="badge-best-price">
                                                <i class="bi bi-trophy-fill me-1"></i> MEILLEUR PRIX
                                            </span>
                                        <?php elseif ($item['price_diff'] !== null && $item['price_diff'] > 0): ?>
                                            <span class="badge bg-light text-danger border fw-semibold">
                                                +<?= number_format($item['price_diff'], 3) ?> DT
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($item['regular_price'] === null): ?>
                                            <span class="badge bg-secondary">Non disponible</span>
                                        <?php elseif ($item['in_stock']): ?>
                                            <span class="badge bg-success bg-opacity-10 text-success"><i class="bi bi-check-circle me-1"></i> En Stock</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger bg-opacity-10 text-danger"><i class="bi bi-x-circle me-1"></i> Épuisé</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Quick Summary Box -->
        <div class="card bg-success bg-opacity-10 border-success border-opacity-25 rounded-4 p-4">
            <div class="d-flex align-items-start gap-3">
                <div class="bg-success text-white p-3 rounded-circle fs-4">
                    <i class="bi bi-calculator-fill"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-success mb-1">Optimisation & Économie Consommateur</h5>
                    <p class="text-dark small mb-0">
                        En choisissant l'enseigne proposant le meilleur prix pour <strong><?= sanitize($product['name']) ?></strong>, le consommateur tunisien économise directement sur son panier sans compromis sur la marque.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
