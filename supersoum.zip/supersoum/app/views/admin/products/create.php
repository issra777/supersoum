<?php
/**
 * Product Create View
 */
?>

<div class="page-header">
    <div class="d-flex align-items-center gap-3">
        <a href="index.php?page=products" class="btn btn-light border p-2 rounded-3" title="Retour">
            <i class="bi bi-arrow-left fs-5"></i>
        </a>
        <div>
            <h1 class="page-title">Ajouter un Nouveau Produit</h1>
            <p class="page-subtitle">Renseignez les détails du produit et ses prix initiaux dans les grandes surfaces.</p>
        </div>
    </div>
</div>

<form action="index.php?page=products&action=store" method="POST" enctype="multipart/form-data">
    <div class="row g-4 mb-4">
        <!-- Left Column: Product Information -->
        <div class="col-lg-7">
            <div class="custom-card mb-4">
                <div class="custom-card-header">
                    <h3 class="custom-card-title">
                        <i class="bi bi-info-circle-fill text-success"></i>
                        <span>Informations Générales</span>
                    </h3>
                </div>
                <div class="custom-card-body">
                    <!-- Product Name -->
                    <div class="mb-3">
                        <label class="form-label fw-bold text-dark small" for="name">Nom du produit <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="Ex: Lait Demi-Écrémé UHT 1L" required>
                    </div>

                    <div class="row g-3 mb-3">
                        <!-- Category -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-dark small" for="category_id">Catégorie <span class="text-danger">*</span></label>
                            <select name="category_id" id="category_id" class="form-select" required>
                                <option value="">Sélectionner une catégorie</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= sanitize($cat['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Brand -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-dark small" for="brand_id">Marque</label>
                            <select name="brand_id" id="brand_id" class="form-select">
                                <option value="">Marque / Générique</option>
                                <?php foreach ($brands as $b): ?>
                                    <option value="<?= $b['id'] ?>"><?= sanitize($b['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <!-- Unit -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-dark small" for="unit">Conditionnement / Unité</label>
                            <input type="text" name="unit" id="unit" class="form-control" placeholder="Ex: Bouteille 1.5L, Paquet 500g" value="1 unité">
                        </div>

                        <!-- Barcode -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold text-dark small" for="barcode">Code-barres (EAN-13)</label>
                            <input type="text" name="barcode" id="barcode" class="form-control" placeholder="Ex: 6194000100011">
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="mb-3">
                        <label class="form-label fw-bold text-dark small" for="description">Description & Caractéristiques</label>
                        <textarea name="description" id="description" rows="3" class="form-control" placeholder="Détails du produit, composition..."></textarea>
                    </div>

                    <!-- Switches -->
                    <div class="d-flex gap-4 pt-2">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="featured" id="featured" value="1">
                            <label class="form-check-label fw-semibold small" for="featured">Mettre en vedette</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="status" id="status" value="active" checked>
                            <label class="form-check-label fw-semibold small" for="status">Actif dans le comparateur</label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Image Upload Card -->
            <div class="custom-card">
                <div class="custom-card-header">
                    <h3 class="custom-card-title">
                        <i class="bi bi-image-fill text-success"></i>
                        <span>Visuel du Produit</span>
                    </h3>
                </div>
                <div class="custom-card-body">
                    <div class="row align-items-center">
                        <div class="col-sm-4 text-center mb-3 mb-sm-0">
                            <img id="imgPreview" src="public/images/products/placeholder.png" alt="Aperçu" class="rounded border p-2 bg-light" style="width: 120px; height: 120px; object-fit: contain;">
                        </div>
                        <div class="col-sm-8">
                            <label class="form-label fw-bold small text-dark">Sélectionner une image</label>
                            <input type="file" name="image" class="form-control image-upload-input" data-preview="imgPreview" accept="image/*">
                            <small class="text-muted d-block mt-1">Formats acceptés : PNG, JPG, SVG, WEBP.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column: Prices across Supermarkets -->
        <div class="col-lg-5">
            <div class="custom-card h-100">
                <div class="custom-card-header">
                    <h3 class="custom-card-title">
                        <i class="bi bi-currency-exchange text-success"></i>
                        <span>Prix par Grande Surface (DT)</span>
                    </h3>
                </div>
                <div class="custom-card-body">
                    <p class="text-muted small mb-4">
                        Saisissez les prix constatés dans les magasins. Le comparateur identifiera automatiquement le meilleur prix.
                    </p>

                    <div class="d-flex flex-column gap-3">
                        <?php foreach ($supermarkets as $market): ?>
                            <div class="market-price-row p-3 rounded-3 border bg-light">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="badge px-2 py-1 rounded" style="background-color: <?= $market['color_hex'] ?>15; color: <?= $market['color_hex'] ?>; border: 1px solid <?= $market['color_hex'] ?>40;">
                                        <?= sanitize($market['name']) ?>
                                    </span>
                                    <div class="form-check form-check-inline m-0">
                                        <input class="form-check-input" type="checkbox" name="prices[<?= $market['id'] ?>][in_stock]" id="stock_<?= $market['id'] ?>" value="1" checked>
                                        <label class="form-check-label small" for="stock_<?= $market['id'] ?>">En stock</label>
                                    </div>
                                </div>
                                <div class="input-group">
                                    <input type="number" step="0.001" min="0" name="prices[<?= $market['id'] ?>][price]" class="form-control multi-market-price-input" placeholder="0.000">
                                    <span class="input-group-text bg-white fw-bold text-muted"><?= CURRENCY ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="mt-4 pt-3 border-top">
                        <button type="submit" class="btn btn-brand w-100 py-3 justify-content-center">
                            <i class="bi bi-check-circle-fill me-2"></i> Enregistrer le Produit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
