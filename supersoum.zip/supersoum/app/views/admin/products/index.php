<?php
/**
 * Products Index View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Gestion des Produits</h1>
        <p class="page-subtitle">Consultez, comparez et mettez à jour les produits référencés dans les grandes surfaces.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="index.php?page=prices" class="btn btn-brand-outline">
            <i class="bi bi-tags"></i>
            <span>Matrice des prix</span>
        </a>
        <a href="index.php?page=products&action=create" class="btn btn-brand">
            <i class="bi bi-plus-lg"></i>
            <span>Nouveau Produit</span>
        </a>
    </div>
</div>

<!-- Filters & Search Toolbar -->
<div class="custom-card mb-4">
    <div class="custom-card-body p-3">
        <form action="index.php" method="GET" class="row g-3 align-items-center">
            <input type="hidden" name="page" value="products">

            <!-- Search Field -->
            <div class="col-lg-4 col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Nom de produit, code-barres..." value="<?= sanitize($filters['search']) ?>">
                </div>
            </div>

            <!-- Category Filter -->
            <div class="col-lg-3 col-md-6">
                <select name="category_id" class="form-select">
                    <option value="">Toutes les catégories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($filters['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                            <?= sanitize($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Brand Filter -->
            <div class="col-lg-2 col-md-4">
                <select name="brand_id" class="form-select">
                    <option value="">Toutes les marques</option>
                    <?php foreach ($brands as $b): ?>
                        <option value="<?= $b['id'] ?>" <?= ($filters['brand_id'] == $b['id']) ? 'selected' : '' ?>>
                            <?= sanitize($b['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Sort -->
            <div class="col-lg-2 col-md-4">
                <select name="sort" class="form-select">
                    <option value="newest" <?= ($filters['sort'] === 'newest') ? 'selected' : '' ?>>Plus récents</option>
                    <option value="name_asc" <?= ($filters['sort'] === 'name_asc') ? 'selected' : '' ?>>Nom (A-Z)</option>
                    <option value="price_asc" <?= ($filters['sort'] === 'price_asc') ? 'selected' : '' ?>>Prix croissant</option>
                    <option value="price_desc" <?= ($filters['sort'] === 'price_desc') ? 'selected' : '' ?>>Prix décroissant</option>
                </select>
            </div>

            <!-- Filter Buttons -->
            <div class="col-lg-1 col-md-4 d-flex gap-2">
                <button type="submit" class="btn btn-brand w-100 p-2 justify-content-center" title="Filtrer">
                    <i class="bi bi-funnel-fill"></i>
                </button>
                <?php if (!empty($filters['search']) || !empty($filters['category_id']) || !empty($filters['brand_id']) || !empty($filters['sort'] !== 'newest')): ?>
                    <a href="index.php?page=products" class="btn btn-light border p-2" title="Réinitialiser">
                        <i class="bi bi-x-lg"></i>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<!-- Products Counter and Quick Tabs -->
<div class="d-flex align-items-center justify-content-between mb-3">
    <div class="text-muted small">
        Affichage de <strong><?= count($products) ?></strong> sur <strong><?= $totalProducts ?></strong> produits
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="index.php?page=products&promo_only=1" class="btn btn-sm <?= isset($filters['promo_only']) ? 'btn-danger' : 'btn-outline-danger' ?> rounded-pill">
            <i class="bi bi-fire me-1"></i> En Promotion
        </a>
        <a href="index.php?page=products&no_price=1" class="btn btn-sm <?= isset($filters['no_price']) ? 'btn-warning' : 'btn-outline-warning' ?> rounded-pill">
            <i class="bi bi-exclamation-triangle me-1"></i> Sans Prix
        </a>
    </div>
</div>

<!-- Products Grid (Modern SaaS Product Cards with Image) -->
<div class="row g-4 mb-4">
    <?php if (empty($products)): ?>
        <div class="col-12">
            <div class="custom-card text-center py-5">
                <div class="mb-3 text-muted">
                    <i class="bi bi-search fs-1"></i>
                </div>
                <h4 class="fw-bold text-dark">Aucun produit trouvé</h4>
                <p class="text-muted">Essayez de modifier vos critères de recherche ou ajoutez un nouveau produit.</p>
                <a href="index.php?page=products&action=create" class="btn btn-brand">
                    <i class="bi bi-plus-lg me-1"></i> Ajouter un produit
                </a>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($products as $prod): ?>
            <?php 
                // Find best supermarket and prices
                $bestMarket = null;
                $lowestPrice = null;
                if (!empty($prod['prices_list'])) {
                    foreach ($prod['prices_list'] as $pr) {
                        if ($pr['is_best_price']) {
                            $bestMarket = $pr['supermarket_name'];
                            $lowestPrice = $pr['effective_price'];
                            break;
                        }
                    }
                }
            ?>
            <div class="col-xl-4 col-md-6">
                <div class="product-grid-card">
                    <!-- Image Container with fallback -->
                    <div class="product-image-container">
                        <img src="public/images/products/<?= sanitize($prod['image'] ?? 'placeholder.png') ?>" 
                             alt="<?= sanitize($prod['name']) ?>" 
                             class="product-img"
                             onerror="this.onerror=null; this.src='public/images/products/placeholder.png';">
                        
                        <!-- Badges Overlay -->
                        <div class="position-absolute top-0 start-0 p-3 d-flex flex-column gap-1">
                            <?php if ($prod['active_promos_count'] > 0): ?>
                                <span class="badge-promo"><i class="bi bi-tag-fill me-1"></i> PROMO</span>
                            <?php endif; ?>
                            <?php if ($prod['featured']): ?>
                                <span class="badge bg-warning text-dark fw-bold" style="font-size:10px;"><i class="bi bi-star-fill"></i> Vedette</span>
                            <?php endif; ?>
                        </div>

                        <div class="position-absolute top-0 end-0 p-3">
                            <span class="badge bg-light text-dark border fw-bold" style="font-size:11px;">
                                <?= sanitize($prod['unit']) ?>
                            </span>
                        </div>
                    </div>

                    <!-- Card Body -->
                    <div class="p-4 d-flex flex-column flex-grow-1">
                        <!-- Category & Brand -->
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <span class="badge bg-success bg-opacity-10 text-success fw-semibold" style="font-size:11px;">
                                <?= sanitize($prod['category_name'] ?? 'Épicerie') ?>
                            </span>
                            <span class="text-muted small fw-medium">
                                <?= sanitize($prod['brand_name'] ?? 'Générique') ?>
                            </span>
                        </div>

                        <!-- Title -->
                        <h4 class="fw-bold text-dark fs-5 mb-2 text-truncate" title="<?= sanitize($prod['name']) ?>">
                            <a href="index.php?page=products&action=show&id=<?= $prod['id'] ?>" class="text-dark hover-text-primary">
                                <?= sanitize($prod['name']) ?>
                            </a>
                        </h4>

                        <!-- Barcode if available -->
                        <?php if (!empty($prod['barcode'])): ?>
                            <div class="text-muted small mb-3">
                                <i class="bi bi-upc-scan me-1"></i> <code><?= sanitize($prod['barcode']) ?></code>
                            </div>
                        <?php endif; ?>

                        <!-- Pricing Section -->
                        <div class="p-3 bg-light rounded-3 mb-3 mt-auto">
                            <?php if ($lowestPrice !== null && $lowestPrice > 0): ?>
                                <div class="d-flex align-items-center justify-content-between mb-1">
                                    <span class="small text-muted fw-bold">MEILLEUR PRIX</span>
                                    <span class="badge-best-price">
                                        <i class="bi bi-trophy-fill"></i> <?= sanitize($bestMarket ?? '') ?>
                                    </span>
                                </div>
                                <div class="d-flex align-items-baseline justify-content-between">
                                    <span class="fs-4 fw-black text-success"><?= formatPrice($lowestPrice) ?></span>
                                    <span class="small text-muted">dans <?= $prod['supermarkets_count'] ?> magasins</span>
                                </div>
                            <?php else: ?>
                                <div class="text-muted small text-center py-1">
                                    <i class="bi bi-info-circle me-1"></i> Aucun prix renseigné
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex align-items-center justify-content-between pt-2 border-top">
                            <a href="index.php?page=products&action=show&id=<?= $prod['id'] ?>" class="btn btn-sm btn-light border fw-semibold">
                                <i class="bi bi-bar-chart-steps me-1"></i> Comparer
                            </a>
                            <div class="d-flex gap-1">
                                <a href="index.php?page=products&action=edit&id=<?= $prod['id'] ?>" class="btn btn-sm btn-light border text-primary" title="Modifier">
                                    <i class="bi bi-pencil-fill"></i>
                                </a>
                                <form action="index.php?page=products&action=delete" method="POST" class="d-inline" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ?');">
                                    <input type="hidden" name="id" value="<?= $prod['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-light border text-danger" title="Supprimer">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
    <nav aria-label="Pagination" class="d-flex justify-content-center">
        <ul class="pagination">
            <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                <a class="page-link" href="index.php?page=products&p=<?= $page - 1 ?>&search=<?= urlencode($filters['search']) ?>&category_id=<?= $filters['category_id'] ?>&brand_id=<?= $filters['brand_id'] ?>&sort=<?= $filters['sort'] ?>">Précédent</a>
            </li>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                    <a class="page-link" href="index.php?page=products&p=<?= $i ?>&search=<?= urlencode($filters['search']) ?>&category_id=<?= $filters['category_id'] ?>&brand_id=<?= $filters['brand_id'] ?>&sort=<?= $filters['sort'] ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                <a class="page-link" href="index.php?page=products&p=<?= $page + 1 ?>&search=<?= urlencode($filters['search']) ?>&category_id=<?= $filters['category_id'] ?>&brand_id=<?= $filters['brand_id'] ?>&sort=<?= $filters['sort'] ?>">Suivant</a>
            </li>
        </ul>
    </nav>
<?php endif; ?>
