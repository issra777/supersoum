<?php
/**
 * Supermarkets View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Grandes Surfaces & Enseignes</h1>
        <p class="page-subtitle">Les 5 principales chaînes de supermarchés et hypermarchés en Tunisie.</p>
    </div>
    <div class="d-flex gap-2">
        <button type="button" class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#addSupermarketModal">
            <i class="bi bi-plus-lg me-1"></i> Ajouter Enseigne
        </button>
    </div>
</div>

<div class="row g-4">
    <?php foreach ($supermarkets as $s): ?>
        <div class="col-xl-4 col-md-6">
            <div class="custom-card h-100">
                <div class="custom-card-body p-4 d-flex flex-column">
                    <!-- Logo Header -->
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="p-2 border rounded-3 bg-white" style="width: 130px; height: 50px; display: flex; align-items: center; justify-content: center;">
                            <img src="public/images/supermarkets/<?= sanitize($s['logo']) ?>" alt="<?= sanitize($s['name']) ?>" style="max-height: 40px; max-width: 100%; object-fit: contain;">
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border p-1" type="button" data-bs-toggle="dropdown">
                                <i class="bi bi-three-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                <li>
                                    <button class="dropdown-item small" data-bs-toggle="modal" data-bs-target="#editSupermarketModal<?= $s['id'] ?>">
                                        <i class="bi bi-pencil-fill me-2 text-primary"></i> Modifier
                                    </button>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form action="index.php?page=supermarkets&action=delete" method="POST" onsubmit="return confirm('Supprimer cette grande surface ?');">
                                        <input type="hidden" name="id" value="<?= $s['id'] ?>">
                                        <button type="submit" class="dropdown-item small text-danger">
                                            <i class="bi bi-trash-fill me-2"></i> Supprimer
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <h4 class="fw-bold text-dark fs-5 mb-1"><?= sanitize($s['name']) ?></h4>

                    <div class="d-flex flex-wrap gap-2 mb-4">
                        <span class="badge bg-light text-secondary border small">
                            <i class="bi bi-shop me-1 text-primary"></i> <?= $s['stores_count'] ?> magasins en Tunisie
                        </span>
                        <span class="badge bg-success bg-opacity-10 text-success small">
                            <i class="bi bi-tags-fill me-1"></i> <?= $s['total_products_priced'] ?> prix enregistrés
                        </span>
                        <span class="badge bg-danger bg-opacity-10 text-danger small">
                            <i class="bi bi-percent me-1"></i> <?= $s['active_promos_count'] ?> promotions
                        </span>
                    </div>

                    <?php if (!empty($s['website'])): ?>
                        <div class="small mb-3">
                            <a href="<?= sanitize($s['website']) ?>" target="_blank" class="text-decoration-none text-muted">
                                <i class="bi bi-link-45deg me-1"></i> <?= sanitize($s['website']) ?>
                            </a>
                        </div>
                    <?php endif; ?>

                    <div class="mt-auto pt-3 border-top d-flex gap-2">
                        <a href="index.php?page=prices" class="btn btn-sm btn-brand-outline w-100">
                            Voir les prix
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Supermarket Modal -->
        <div class="modal fade" id="editSupermarketModal<?= $s['id'] ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg rounded-4">
                    <form action="index.php?page=supermarkets&action=update" method="POST">
                        <input type="hidden" name="id" value="<?= $s['id'] ?>">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold">Modifier Grande Surface</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Nom de l'enseigne</label>
                                <input type="text" name="name" class="form-control" value="<?= sanitize($s['name']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Couleur Thème (Hex)</label>
                                <input type="color" name="color_hex" class="form-control form-control-color w-100" value="<?= sanitize($s['color_hex']) ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Nombre de points de vente</label>
                                <input type="number" name="stores_count" class="form-control" value="<?= $s['stores_count'] ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Site Internet</label>
                                <input type="url" name="website" class="form-control" value="<?= sanitize($s['website'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-brand">Enregistrer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Add Supermarket Modal -->
<div class="modal fade" id="addSupermarketModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form action="index.php?page=supermarkets&action=store" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Nouvelle Grande Surface</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nom <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="Ex: Monoprix" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Couleur Principale</label>
                        <input type="color" name="color_hex" class="form-control form-control-color w-100" value="#16A34A">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nombre de magasins</label>
                        <input type="number" name="stores_count" class="form-control" value="10">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Site Internet</label>
                        <input type="url" name="website" class="form-control" placeholder="https://www.exemple.tn">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-brand">Ajouter l'enseigne</button>
                </div>
            </form>
        </div>
    </div>
</div>
