<?php
/**
 * Brands Index View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Gestion des Marques</h1>
        <p class="page-subtitle">Fabricants et marques de grande distribution tunisiennes et internationales.</p>
    </div>
    <div class="d-flex gap-2">
        <button type="button" class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#addBrandModal">
            <i class="bi bi-plus-lg me-1"></i> Nouvelle Marque
        </button>
    </div>
</div>

<div class="row g-4">
    <?php foreach ($brands as $b): ?>
        <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="custom-card h-100">
                <div class="custom-card-body p-4 d-flex flex-column">
                    <div class="d-flex align-items-start justify-content-between mb-3">
                        <div class="bg-light p-3 rounded-3 text-success fs-3">
                            <i class="bi bi-bookmark-star-fill"></i>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border p-1" type="button" data-bs-toggle="dropdown">
                                <i class="bi bi-three-dots-vertical"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                <li>
                                    <button class="dropdown-item small" data-bs-toggle="modal" data-bs-target="#editBrandModal<?= $b['id'] ?>">
                                        <i class="bi bi-pencil-fill me-2 text-primary"></i> Modifier
                                    </button>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form action="index.php?page=brands&action=delete" method="POST" onsubmit="return confirm('Supprimer cette marque ?');">
                                        <input type="hidden" name="id" value="<?= $b['id'] ?>">
                                        <button type="submit" class="dropdown-item small text-danger">
                                            <i class="bi bi-trash-fill me-2"></i> Supprimer
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <h4 class="fw-bold text-dark fs-5 mb-1"><?= sanitize($b['name']) ?></h4>
                    
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span class="badge bg-light text-secondary border small">
                            <i class="bi bi-geo-alt-fill text-danger me-1"></i> <?= sanitize($b['origin']) ?>
                        </span>
                        <span class="badge bg-success bg-opacity-10 text-success small fw-semibold">
                            <?= $b['products_count'] ?> produits
                        </span>
                    </div>

                    <div class="mt-auto pt-3 border-top">
                        <a href="index.php?page=products&brand_id=<?= $b['id'] ?>" class="btn btn-sm btn-light w-100 border text-dark fw-semibold">
                            Voir les produits &rarr;
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Brand Modal -->
        <div class="modal fade" id="editBrandModal<?= $b['id'] ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg rounded-4">
                    <form action="index.php?page=brands&action=update" method="POST">
                        <input type="hidden" name="id" value="<?= $b['id'] ?>">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold">Modifier Marque</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Nom de la marque</label>
                                <input type="text" name="name" class="form-control" value="<?= sanitize($b['name']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Origine</label>
                                <input type="text" name="origin" class="form-control" value="<?= sanitize($b['origin']) ?>">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-brand">Enregistrer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Add Brand Modal -->
<div class="modal fade" id="addBrandModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form action="index.php?page=brands&action=store" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Nouvelle Marque</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nom de la marque <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="Ex: Délice Danone" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Origine</label>
                        <input type="text" name="origin" class="form-control" placeholder="Tunisie" value="Tunisie">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-brand">Ajouter la marque</button>
                </div>
            </form>
        </div>
    </div>
</div>
