<?php
/**
 * Statistics View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Statistiques & Analyse des Prix</h1>
        <p class="page-subtitle">Rapports comparatifs sur la compétitivité tarifaire des enseignes en Tunisie.</p>
    </div>
</div>

<!-- Supermarket Competitiveness Ranking (Basket index) -->
<div class="row g-4 mb-4">
    <div class="col-lg-12">
        <div class="custom-card">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-trophy-fill text-warning"></i>
                    <span>Classement Compétitivité Prix (Indice Panier Type)</span>
                </h3>
                <span class="badge bg-success bg-opacity-10 text-success px-3 py-1 fw-bold">10 Produits Essentiels</span>
            </div>
            <div class="table-responsive">
                <table class="comparison-table">
                    <thead>
                        <tr>
                            <th>Rang</th>
                            <th>Grande Surface</th>
                            <th>Prix Moyen Unitaire</th>
                            <th>Panier Étalon (10 Articles)</th>
                            <th>Volume de Promos</th>
                            <th>Indice Compétitivité</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($basketComparison as $idx => $row): ?>
                            <tr class="<?= ($idx === 0) ? 'best-price-row' : '' ?>">
                                <td>
                                    <?php if ($idx === 0): ?>
                                        <span class="badge bg-warning text-dark fs-6 px-3 py-1"><i class="bi bi-award-fill"></i> 1er</span>
                                    <?php else: ?>
                                        <span class="fw-bold text-muted ps-2">#<?= $idx + 1 ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge px-3 py-2 rounded-2 fw-bold" style="background-color: <?= $row['color'] ?>15; color: <?= $row['color'] ?>; border: 1px solid <?= $row['color'] ?>40;">
                                        <?= sanitize($row['name']) ?>
                                    </span>
                                </td>
                                <td>
                                    <strong class="text-dark"><?= formatPrice($row['avg_price']) ?></strong>
                                </td>
                                <td>
                                    <strong class="fs-5 <?= ($idx === 0) ? 'text-success' : 'text-dark' ?>">
                                        <?= formatPrice($row['basket_total']) ?>
                                    </strong>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border">
                                        <i class="bi bi-fire text-danger me-1"></i> <?= $row['promos'] ?> promotions
                                    </span>
                                </td>
                                <td>
                                    <?php if ($idx === 0): ?>
                                        <span class="badge-best-price">Le Moins Cher</span>
                                    <?php else: ?>
                                        <span class="text-muted small">Standard</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Comparison Charts Grid -->
<div class="row g-4 mb-4">
    <!-- Basket Comparison Chart -->
    <div class="col-lg-7">
        <div class="custom-card h-100">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-bar-chart-steps text-success"></i>
                    <span>Comparatif Panier Moyen (DT)</span>
                </h3>
            </div>
            <div class="custom-card-body" style="height: 320px;">
                <canvas id="basketChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Category Distribution Chart -->
    <div class="col-lg-5">
        <div class="custom-card h-100">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-pie-chart-fill text-primary"></i>
                    <span>Répartition par Catégorie</span>
                </h3>
            </div>
            <div class="custom-card-body d-flex align-items-center justify-content-center" style="height: 320px;">
                <canvas id="statsCategoryChart"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // 1. Basket Chart
    SuperSoumCharts.initBasketChart(
        'basketChart',
        <?= json_encode(array_column($basketComparison, 'name')) ?>,
        <?= json_encode(array_map(fn($r) => round($r['basket_total'], 3), $basketComparison)) ?>,
        <?= json_encode(array_column($basketComparison, 'color')) ?>
    );

    // 2. Stats Category Doughnut
    SuperSoumCharts.initCategoryChart(
        'statsCategoryChart',
        <?= json_encode(array_column($catData, 'name')) ?>,
        <?= json_encode(array_column($catData, 'total')) ?>
    );
});
</script>
