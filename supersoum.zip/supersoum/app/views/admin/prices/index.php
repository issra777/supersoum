<?php
/**
 * Prices Comparison Matrix View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Matrice Comparatrice des Prix</h1>
        <p class="page-subtitle">Visualisez et comparez les prix côte à côte pour chaque produit dans les 5 enseignes.</p>
    </div>
</div>

<!-- Filter Toolbar -->
<div class="custom-card mb-4">
    <div class="custom-card-body p-3">
        <form action="index.php" method="GET" class="row g-3 align-items-center">
            <input type="hidden" name="page" value="prices">

            <div class="col-lg-6">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Rechercher produit..." value="<?= sanitize($filters['search']) ?>">
                </div>
            </div>

            <div class="col-lg-4">
                <select name="category_id" class="form-select">
                    <option value="">Toutes les catégories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($filters['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                            <?= sanitize($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-lg-2 d-flex gap-2">
                <button type="submit" class="btn btn-brand w-100">Filtrer</button>
                <?php if (!empty($filters['search']) || !empty($filters['category_id'])): ?>
                    <a href="index.php?page=prices" class="btn btn-light border p-2" title="Réinitialiser"><i class="bi bi-x-lg"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<!-- Comparison Matrix Table -->
<div class="custom-card mb-4">
    <div class="custom-card-header">
        <h3 class="custom-card-title">
            <i class="bi bi-table text-success"></i>
            <span>Tableau Comparatif des Prix Multi-Enseignes</span>
        </h3>
        <span class="badge bg-success bg-opacity-10 text-success fw-bold px-3 py-1">
            <i class="bi bi-trophy-fill text-warning me-1"></i> Vert = Meilleur Prix Identifié
        </span>
    </div>
    <div class="table-responsive">
        <table class="comparison-table">
            <thead>
                <tr>
                    <th style="min-width: 240px;">Produit</th>
                    <?php foreach ($supermarkets as $sm): ?>
                        <th class="text-center" style="min-width: 120px;">
                            <span class="badge px-2 py-1 rounded" style="background-color: <?= $sm['color_hex'] ?>15; color: <?= $sm['color_hex'] ?>; border: 1px solid <?= $sm['color_hex'] ?>40;">
                                <?= sanitize($sm['name']) ?>
                            </span>
                        </th>
                    <?php endforeach; ?>
                    <th class="text-center" style="min-width: 140px;">Meilleur Prix</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="<?= count($supermarkets) + 3 ?>" class="text-center py-5 text-muted">
                            Aucun produit trouvé dans la matrice de prix.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $p): ?>
                        <?php
                            // Calculate min effective price for this product
                            $minPrice = null;
                            $bestMarketName = null;
                            foreach ($supermarkets as $sm) {
                                if (isset($p['prices_by_market'][$sm['id']])) {
                                    $prData = $p['prices_by_market'][$sm['id']];
                                    $eff = (float)$prData['effective_price'];
                                    if ($eff > 0 && ($minPrice === null || $eff < $minPrice)) {
                                        $minPrice = $eff;
                                        $bestMarketName = $sm['name'];
                                    }
                                }
                            }
                        ?>
                        <tr>
                            <!-- Product Name & Image -->
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <img src="public/images/products/<?= sanitize($p['image']) ?>" alt="" class="rounded border p-1" style="width: 44px; height: 44px; object-fit: contain; background: #fff;" onerror="this.onerror=null; this.src='public/images/products/placeholder.png';">
                                    <div>
                                        <div class="fw-bold text-dark"><?= sanitize($p['name']) ?></div>
                                        <div class="small text-muted"><?= sanitize($p['category_name']) ?> • <span class="badge bg-light text-dark border"><?= sanitize($p['unit']) ?></span></div>
                                    </div>
                                </div>
                            </td>

                            <!-- Price for each supermarket -->
                            <?php foreach ($supermarkets as $sm): ?>
                                <?php 
                                    $marketPriceData = $p['prices_by_market'][$sm['id']] ?? null;
                                    $priceVal = $marketPriceData ? (float)$marketPriceData['effective_price'] : null;
                                    $isLowest = ($minPrice !== null && $priceVal !== null && $priceVal == $minPrice);
                                    $hasPromo = $marketPriceData && $marketPriceData['promo_id'] && $marketPriceData['promo_active'];
                                ?>
                                <td class="text-center <?= $isLowest ? 'bg-success bg-opacity-10 fw-bold text-success' : '' ?>">
                                    <?php if ($priceVal !== null && $priceVal > 0): ?>
                                        <div class="d-flex flex-column align-items-center">
                                            <span class="fs-6 <?= $isLowest ? 'text-success fw-black' : 'text-dark' ?>">
                                                <?= number_format($priceVal, 3, '.', ' ') ?> <?= CURRENCY ?>
                                            </span>
                                            <?php if ($hasPromo): ?>
                                                <span class="badge-promo" style="font-size: 9px; padding: 2px 5px;">-<?= $marketPriceData['discount_percentage'] ?>%</span>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted small">—</span>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>

                            <!-- Best Price Column -->
                            <td class="text-center">
                                <?php if ($minPrice !== null): ?>
                                    <span class="badge-best-price">
                                        <i class="bi bi-trophy-fill"></i> <?= formatPrice($minPrice) ?> (<?= sanitize($bestMarketName) ?>)
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted small">Aucun prix</span>
                                <?php endif; ?>
                            </td>

                            <!-- Actions (Quick Edit Modal) -->
                            <td class="text-center">
                                <button type="button" class="btn btn-sm btn-light border text-primary" data-bs-toggle="modal" data-bs-target="#editPricesModal<?= $p['id'] ?>" title="Modifier les prix">
                                    <i class="bi bi-pencil-fill me-1"></i> Prix
                                </button>
                            </td>
                        </tr>

                        <!-- Quick Prices Edit Modal -->
                        <div class="modal fade" id="editPricesModal<?= $p['id'] ?>" tabindex="-1">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content border-0 shadow-lg rounded-4">
                                    <form action="index.php?page=prices&action=update" method="POST">
                                        <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                                        <div class="modal-header">
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="public/images/products/<?= sanitize($p['image']) ?>" alt="" style="width:32px; height:32px; object-fit:contain;">
                                                <h5 class="modal-title fw-bold">Modifier Prix : <?= sanitize($p['name']) ?></h5>
                                            </div>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="d-flex flex-column gap-3">
                                                <?php foreach ($supermarkets as $sm): ?>
                                                    <?php $curPrice = $p['prices_by_market'][$sm['id']]['regular_price'] ?? ''; ?>
                                                    <div class="d-flex align-items-center justify-content-between p-2 rounded bg-light border">
                                                        <span class="badge px-2 py-1 rounded" style="background-color: <?= $sm['color_hex'] ?>15; color: <?= $sm['color_hex'] ?>;">
                                                            <?= sanitize($sm['name']) ?>
                                                        </span>
                                                        <div class="input-group" style="max-width: 180px;">
                                                            <input type="number" step="0.001" min="0" name="prices[<?= $sm['id'] ?>][price]" class="form-control form-control-sm" value="<?= $curPrice ?>" placeholder="0.000">
                                                            <span class="input-group-text bg-white small"><?= CURRENCY ?></span>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                                            <button type="submit" class="btn btn-brand">Enregistrer les prix</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
    <nav class="d-flex justify-content-center">
        <ul class="pagination">
            <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                <a class="page-link" href="index.php?page=prices&p=<?= $page - 1 ?>&search=<?= urlencode($filters['search']) ?>&category_id=<?= $filters['category_id'] ?>">Précédent</a>
            </li>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                    <a class="page-link" href="index.php?page=prices&p=<?= $i ?>&search=<?= urlencode($filters['search']) ?>&category_id=<?= $filters['category_id'] ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                <a class="page-link" href="index.php?page=prices&p=<?= $page + 1 ?>&search=<?= urlencode($filters['search']) ?>&category_id=<?= $filters['category_id'] ?>">Suivant</a>
            </li>
        </ul>
    </nav>
<?php endif; ?>
