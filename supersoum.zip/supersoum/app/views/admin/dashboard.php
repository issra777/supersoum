<?php
/**
 * Admin Dashboard View
 */
?>

<!-- Page Header -->
<div class="page-header">
    <div>
        <h1 class="page-title">Tableau de bord SuperSoum</h1>
        <p class="page-subtitle">Aperçu en temps réel du catalogue, des prix comparés et des promotions actives en Tunisie.</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="index.php?page=prices" class="btn btn-brand-outline">
            <i class="bi bi-tags"></i>
            <span>Matrice des prix</span>
        </a>
        <a href="index.php?page=products&action=create" class="btn btn-brand">
            <i class="bi bi-plus-lg"></i>
            <span>Ajouter Produit</span>
        </a>
    </div>
</div>

<!-- KPI Cards Grid (6 Indicators) -->
<div class="row g-4 mb-4">
    <!-- 1. Total Produits -->
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="kpi-card">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <span class="kpi-label">Produits</span>
                <div class="kpi-icon-wrap kpi-icon-green">
                    <i class="bi bi-box-seam"></i>
                </div>
            </div>
            <div class="kpi-value counter-value" data-target="<?= $stats['total_products'] ?>"><?= $stats['total_products'] ?></div>
            <div class="small text-muted mt-2">
                <span class="text-success fw-bold"><i class="bi bi-check-circle"></i> Référencés</span>
            </div>
        </div>
    </div>

    <!-- 2. Grandes Surfaces -->
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="kpi-card">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <span class="kpi-label">Enseignes</span>
                <div class="kpi-icon-wrap kpi-icon-blue">
                    <i class="bi bi-shop"></i>
                </div>
            </div>
            <div class="kpi-value counter-value" data-target="<?= $stats['total_supermarkets'] ?>"><?= $stats['total_supermarkets'] ?></div>
            <div class="small text-muted mt-2">
                <span class="text-info fw-bold">MG, Aziza, Carrefour...</span>
            </div>
        </div>
    </div>

    <!-- 3. Promotions Actives -->
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="kpi-card">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <span class="kpi-label">Promos Actives</span>
                <div class="kpi-icon-wrap kpi-icon-rose">
                    <i class="bi bi-percent"></i>
                </div>
            </div>
            <div class="kpi-value text-danger counter-value" data-target="<?= $stats['active_promotions'] ?>"><?= $stats['active_promotions'] ?></div>
            <div class="small text-muted mt-2">
                <span class="text-danger fw-bold"><i class="bi bi-fire"></i> Jusqu'à -25%</span>
            </div>
        </div>
    </div>

    <!-- 4. Utilisateurs -->
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="kpi-card">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <span class="kpi-label">Utilisateurs</span>
                <div class="kpi-icon-wrap kpi-icon-amber">
                    <i class="bi bi-people"></i>
                </div>
            </div>
            <div class="kpi-value counter-value" data-target="<?= $stats['total_users'] ?>"><?= $stats['total_users'] ?></div>
            <div class="small text-muted mt-2">
                <span class="text-warning fw-bold"><i class="bi bi-person-check"></i> Actifs</span>
            </div>
        </div>
    </div>

    <!-- 5. Prix Mis à Jour Récent -->
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="kpi-card">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <span class="kpi-label">Prix Mis à Jour</span>
                <div class="kpi-icon-wrap kpi-icon-green">
                    <i class="bi bi-arrow-repeat"></i>
                </div>
            </div>
            <div class="kpi-value counter-value" data-target="<?= $stats['updated_prices_recent'] ?>"><?= $stats['updated_prices_recent'] ?></div>
            <div class="small text-muted mt-2">
                <span class="text-success fw-bold">7 derniers jours</span>
            </div>
        </div>
    </div>

    <!-- 6. Produits sans Prix -->
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="kpi-card">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <span class="kpi-label">Sans Prix</span>
                <div class="kpi-icon-wrap bg-secondary bg-opacity-10 text-secondary">
                    <i class="bi bi-exclamation-circle"></i>
                </div>
            </div>
            <div class="kpi-value <?= $stats['products_without_price'] > 0 ? 'text-warning' : 'text-success' ?> counter-value" data-target="<?= $stats['products_without_price'] ?>"><?= $stats['products_without_price'] ?></div>
            <div class="small text-muted mt-2">
                <a href="index.php?page=products&no_price=1" class="text-decoration-none small text-secondary">À compléter &rarr;</a>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row 1: Products by Category & Promotions by Supermarket -->
<div class="row g-4 mb-4">
    <!-- Chart 1: Categories -->
    <div class="col-lg-5">
        <div class="custom-card h-100">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-pie-chart-fill text-success"></i>
                    <span>Produits par Catégorie</span>
                </h3>
                <a href="index.php?page=categories" class="btn btn-sm btn-light border">Gérer</a>
            </div>
            <div class="custom-card-body d-flex align-items-center justify-content-center" style="height: 320px;">
                <canvas id="categoryChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Chart 2: Promotions by Supermarket -->
    <div class="col-lg-7">
        <div class="custom-card h-100">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-bar-chart-fill text-danger"></i>
                    <span>Promotions par Grande Surface</span>
                </h3>
                <span class="badge bg-danger bg-opacity-10 text-danger px-3 py-2 fw-bold">Grandes Surfaces Tunisie</span>
            </div>
            <div class="custom-card-body" style="height: 320px;">
                <canvas id="promotionsChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row 2: Price Evolution & Products count per Supermarket -->
<div class="row g-4 mb-4">
    <!-- Chart 3: Price Evolution -->
    <div class="col-lg-7">
        <div class="custom-card h-100">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-graph-up text-primary"></i>
                    <span>Évolution de l'Indice Moyen des Prix</span>
                </h3>
                <span class="text-muted small">Moyenne trimestrielle</span>
            </div>
            <div class="custom-card-body" style="height: 300px;">
                <canvas id="evolutionChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Chart 4: Supermarkets Products Count -->
    <div class="col-lg-5">
        <div class="custom-card h-100">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-shop-window text-info"></i>
                    <span>Couverture Produits par Enseigne</span>
                </h3>
                <a href="index.php?page=supermarkets" class="btn btn-sm btn-light border">Voir Enseignes</a>
            </div>
            <div class="custom-card-body" style="height: 300px;">
                <canvas id="supermarketsChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Bottom Row: Recent Price Updates & Best Active Promos -->
<div class="row g-4">
    <!-- Recent Price Updates Table -->
    <div class="col-lg-8">
        <div class="custom-card">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-clock-history text-success"></i>
                    <span>Dernières Mises à Jour de Prix</span>
                </h3>
                <a href="index.php?page=prices" class="btn btn-sm btn-brand-outline">Voir tout</a>
            </div>
            <div class="table-responsive">
                <table class="comparison-table">
                    <thead>
                        <tr>
                            <th>Produit</th>
                            <th>Grande Surface</th>
                            <th>Prix Actuel</th>
                            <th>Disponibilité</th>
                            <th>Date MàJ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recentUpdates)): ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">Aucune mise à jour récente</td></tr>
                        <?php else: ?>
                            <?php foreach ($recentUpdates as $up): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-3">
                                            <img src="public/images/products/<?= sanitize($up['product_image'] ?? 'placeholder.png') ?>" alt="" class="rounded" style="width:36px; height:36px; object-fit:contain; background:#f8fafc; border:1px solid #e2e8f0;">
                                            <span class="fw-bold text-dark"><?= sanitize($up['product_name']) ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge px-2 py-1 rounded" style="background-color: <?= $up['color_hex'] ?>15; color: <?= $up['color_hex'] ?>; border: 1px solid <?= $up['color_hex'] ?>40;">
                                            <?= sanitize($up['supermarket_name']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong class="text-dark fs-6"><?= formatPrice($up['price']) ?></strong>
                                    </td>
                                    <td>
                                        <?php if ($up['in_stock']): ?>
                                            <span class="badge bg-success bg-opacity-10 text-success"><i class="bi bi-check-circle me-1"></i> En stock</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger bg-opacity-10 text-danger"><i class="bi bi-x-circle me-1"></i> Rupture</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-muted small">
                                        <?= date('d/m/Y H:i', strtotime($up['last_updated'])) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Active Deals Spotlight -->
    <div class="col-lg-4">
        <div class="custom-card">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-lightning-charge-fill text-warning"></i>
                    <span>Promotions Vedettes</span>
                </h3>
                <a href="index.php?page=promotions" class="small text-success fw-bold text-decoration-none">Toutes &rarr;</a>
            </div>
            <div class="custom-card-body p-3">
                <div class="d-flex flex-column gap-3">
                    <?php foreach ($topPromos as $promo): ?>
                        <div class="p-3 rounded-3 border bg-light d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-3">
                                <img src="public/images/products/<?= sanitize($promo['product_image']) ?>" alt="" style="width: 44px; height: 44px; object-fit: contain; background: white; border-radius: 8px; padding: 2px;">
                                <div>
                                    <div class="fw-bold text-dark text-truncate" style="max-width: 140px;"><?= sanitize($promo['product_name']) ?></div>
                                    <div class="small text-muted"><?= sanitize($promo['supermarket_name']) ?></div>
                                </div>
                            </div>
                            <div class="text-end">
                                <span class="badge-promo mb-1 d-inline-block">-<?= $promo['discount_percentage'] ?>%</span>
                                <div class="fw-bold text-success small"><?= formatPrice($promo['promo_price']) ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js Initializations Script -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    // 1. Categories Doughnut
    SuperSoumCharts.initCategoryChart(
        'categoryChart', 
        <?= json_encode($chartCategories['labels']) ?>, 
        <?= json_encode($chartCategories['data']) ?>
    );

    // 2. Promotions Bar Chart
    SuperSoumCharts.initPromotionsChart(
        'promotionsChart',
        <?= json_encode($chartPromotions['labels']) ?>,
        <?= json_encode($chartPromotions['data']) ?>,
        <?= json_encode($chartPromotions['colors']) ?>
    );

    // 3. Price Evolution Line Chart
    SuperSoumCharts.initEvolutionChart(
        'evolutionChart',
        <?= json_encode($chartEvolution['labels']) ?>,
        <?= json_encode($chartEvolution['data']) ?>
    );

    // 4. Supermarkets Coverage Bar Chart
    SuperSoumCharts.initPromotionsChart(
        'supermarketsChart',
        <?= json_encode($chartSupermarkets['labels']) ?>,
        <?= json_encode($chartSupermarkets['data']) ?>,
        <?= json_encode($chartSupermarkets['colors']) ?>
    );
});
</script>
