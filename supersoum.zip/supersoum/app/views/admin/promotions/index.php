<?php
/**
 * Promotions View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Promotions & Remises</h1>
        <p class="page-subtitle">Offres spéciales, catalogues promotionnels et remises actives dans les grandes surfaces.</p>
    </div>
    <div class="d-flex gap-2">
        <button type="button" class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#addPromotionModal">
            <i class="bi bi-plus-lg me-1"></i> Nouvelle Promotion
        </button>
    </div>
</div>

<div class="row g-4 mb-4">
    <?php if (empty($promotions)): ?>
        <div class="col-12">
            <div class="custom-card text-center py-5">
                <i class="bi bi-percent fs-1 text-muted mb-3 d-block"></i>
                <h4 class="fw-bold text-dark">Aucune promotion enregistrée</h4>
                <p class="text-muted">Créez votre première promotion de grande surface dès maintenant.</p>
                <button type="button" class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#addPromotionModal">
                    <i class="bi bi-plus-lg me-1"></i> Créer une promotion
                </button>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($promotions as $promo): ?>
            <?php 
                $isExpired = strtotime($promo['end_date']) < strtotime('today');
            ?>
            <div class="col-xl-3 col-lg-4 col-md-6">
                <div class="custom-card h-100 position-relative <?= $isExpired ? 'opacity-75' : '' ?>">
                    <!-- Discount Badge -->
                    <div class="position-absolute top-0 end-0 p-3">
                        <span class="badge-promo fs-6 shadow-sm">
                            -<?= $promo['discount_percentage'] ?>%
                        </span>
                    </div>

                    <div class="custom-card-body p-4 d-flex flex-column">
                        <div class="mb-3">
                            <span class="badge px-2 py-1 rounded small fw-bold mb-2" style="background-color: <?= $promo['color_hex'] ?>15; color: <?= $promo['color_hex'] ?>; border: 1px solid <?= $promo['color_hex'] ?>40;">
                                <?= sanitize($promo['supermarket_name']) ?>
                            </span>
                            <?php if ($isExpired): ?>
                                <span class="badge bg-secondary ms-1">Expirée</span>
                            <?php else: ?>
                                <span class="badge bg-success bg-opacity-10 text-success ms-1"><i class="bi bi-check-circle"></i> En cours</span>
                            <?php endif; ?>
                        </div>

                        <!-- Product visual -->
                        <div class="text-center my-2 p-2 bg-light rounded-3">
                            <img src="public/images/products/<?= sanitize($promo['product_image']) ?>" alt="" style="height: 90px; max-width: 100%; object-fit: contain;" onerror="this.onerror=null; this.src='public/images/products/placeholder.png';">
                        </div>

                        <!-- Title -->
                        <h4 class="fw-bold text-dark fs-6 mb-1 text-truncate" title="<?= sanitize($promo['product_name']) ?>">
                            <?= sanitize($promo['product_name']) ?>
                        </h4>

                        <div class="text-muted small mb-3">
                            <?= sanitize($promo['title'] ?: 'Offre Spéciale Catalogue') ?>
                        </div>

                        <!-- Pricing Breakdown -->
                        <div class="p-3 bg-light rounded-3 mb-3 mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="text-muted small">Prix initial :</span>
                                <span class="text-decoration-line-through text-muted"><?= formatPrice($promo['original_price']) ?></span>
                            </div>
                            <div class="d-flex justify-content-between align-items-baseline">
                                <span class="fw-bold text-dark small">Prix Promo :</span>
                                <span class="fs-4 fw-black text-danger"><?= formatPrice($promo['promo_price']) ?></span>
                            </div>
                        </div>

                        <!-- Validity Dates -->
                        <div class="d-flex justify-content-between text-muted small mb-3" style="font-size: 11px;">
                            <span>Du <?= date('d/m/Y', strtotime($promo['start_date'])) ?></span>
                            <span>Au <strong><?= date('d/m/Y', strtotime($promo['end_date'])) ?></strong></span>
                        </div>

                        <!-- Action Bar -->
                        <div class="pt-2 border-top d-flex gap-2">
                            <button type="button" class="btn btn-sm btn-light border w-100 text-primary fw-semibold" data-bs-toggle="modal" data-bs-target="#editPromoModal<?= $promo['id'] ?>">
                                <i class="bi bi-pencil-fill me-1"></i> Modifier
                            </button>
                            <form action="index.php?page=promotions&action=delete" method="POST" class="d-inline" onsubmit="return confirm('Supprimer cette promotion ?');">
                                <input type="hidden" name="id" value="<?= $promo['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-light border text-danger">
                                    <i class="bi bi-trash-fill"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Edit Promotion Modal -->
            <div class="modal fade" id="editPromoModal<?= $promo['id'] ?>" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0 shadow-lg rounded-4">
                        <form action="index.php?page=promotions&action=update" method="POST">
                            <input type="hidden" name="id" value="<?= $promo['id'] ?>">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold">Modifier Promotion</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Titre promotion</label>
                                    <input type="text" name="title" class="form-control" value="<?= sanitize($promo['title'] ?? '') ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Produit</label>
                                    <select name="product_id" class="form-select" required>
                                        <?php foreach ($products as $p): ?>
                                            <option value="<?= $p['id'] ?>" <?= ($promo['product_id'] == $p['id']) ? 'selected' : '' ?>>
                                                <?= sanitize($p['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Grande Surface</label>
                                    <select name="supermarket_id" class="form-select" required>
                                        <?php foreach ($supermarkets as $sm): ?>
                                            <option value="<?= $sm['id'] ?>" <?= ($promo['supermarket_id'] == $sm['id']) ? 'selected' : '' ?>>
                                                <?= sanitize($sm['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="row g-3 mb-3">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Prix Initial (DT)</label>
                                        <input type="number" step="0.001" min="0" name="original_price" class="form-control" value="<?= $promo['original_price'] ?>" required>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Prix Promo (DT)</label>
                                        <input type="number" step="0.001" min="0" name="promo_price" class="form-control" value="<?= $promo['promo_price'] ?>" required>
                                    </div>
                                </div>
                                <div class="row g-3 mb-3">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Date Début</label>
                                        <input type="date" name="start_date" class="form-control" value="<?= $promo['start_date'] ?>" required>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Date Fin</label>
                                        <input type="date" name="end_date" class="form-control" value="<?= $promo['end_date'] ?>" required>
                                    </div>
                                </div>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="active" value="1" <?= $promo['active'] ? 'checked' : '' ?>>
                                    <label class="form-check-label small fw-semibold">Promotion Active</label>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                                <button type="submit" class="btn btn-brand">Enregistrer</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Add Promotion Modal -->
<div class="modal fade" id="addPromotionModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form action="index.php?page=promotions&action=store" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Créer une Promotion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Titre promotion</label>
                        <input type="text" name="title" class="form-control" placeholder="Ex: Festival Ramadan -20%">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Produit <span class="text-danger">*</span></label>
                        <select name="product_id" class="form-select" required>
                            <option value="">Choisir un produit</option>
                            <?php foreach ($products as $p): ?>
                                <option value="<?= $p['id'] ?>"><?= sanitize($p['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Grande Surface <span class="text-danger">*</span></label>
                        <select name="supermarket_id" class="form-select" required>
                            <option value="">Choisir une enseigne</option>
                            <?php foreach ($supermarkets as $sm): ?>
                                <option value="<?= $sm['id'] ?>"><?= sanitize($sm['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-4">
                            <label class="form-label small fw-bold">Prix Initial</label>
                            <input type="number" step="0.001" min="0" name="original_price" id="promo_orig_price" class="form-control" placeholder="0.000" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-bold">Remise %</label>
                            <input type="number" min="1" max="99" name="discount_percentage" id="promo_discount_percent" class="form-control" placeholder="20">
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-bold">Prix Promo</label>
                            <input type="number" step="0.001" min="0" name="promo_price" id="promo_new_price" class="form-control" placeholder="0.000" required>
                        </div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Date Début</label>
                            <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Date Fin</label>
                            <input type="date" name="end_date" class="form-control" value="<?= date('Y-m-d', strtotime('+14 days')) ?>" required>
                        </div>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="active" value="1" checked>
                        <label class="form-check-label small fw-semibold">Promotion Active</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-brand">Ajouter la promotion</button>
                </div>
            </form>
        </div>
    </div>
</div>
