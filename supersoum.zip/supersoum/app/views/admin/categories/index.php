<?php
/**
 * Categories View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Gestion des Catégories</h1>
        <p class="page-subtitle">Organisez les rayons et sous-catégories des grandes surfaces.</p>
    </div>
    <div class="d-flex gap-2">
        <button type="button" class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
            <i class="bi bi-plus-lg me-1"></i> Nouvelle Catégorie
        </button>
    </div>
</div>

<div class="row g-4">
    <?php foreach ($categories as $cat): ?>
        <div class="col-xl-4 col-md-6">
            <div class="custom-card h-100">
                <div class="custom-card-header bg-light">
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-success bg-opacity-10 text-success p-2 rounded-3 fs-5">
                            <i class="bi <?= sanitize($cat['icon'] ?: 'bi-box-seam') ?>"></i>
                        </div>
                        <div>
                            <h4 class="fw-bold text-dark fs-6 mb-0"><?= sanitize($cat['name']) ?></h4>
                            <span class="badge bg-white text-muted border small"><?= $cat['products_count'] ?> produits</span>
                        </div>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-light border p-1" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-three-dots-vertical"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                            <li>
                                <button class="dropdown-item small" data-bs-toggle="modal" data-bs-target="#editCategoryModal<?= $cat['id'] ?>">
                                    <i class="bi bi-pencil-fill me-2 text-primary"></i> Modifier
                                </button>
                            </li>
                            <li>
                                <button class="dropdown-item small" data-bs-toggle="modal" data-bs-target="#addSubcategoryModal<?= $cat['id'] ?>">
                                    <i class="bi bi-plus-circle me-2 text-success"></i> Ajouter sous-catégorie
                                </button>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="index.php?page=categories&action=delete" method="POST" onsubmit="return confirm('Supprimer cette catégorie ?');">
                                    <input type="hidden" name="id" value="<?= $cat['id'] ?>">
                                    <button type="submit" class="dropdown-item small text-danger">
                                        <i class="bi bi-trash-fill me-2"></i> Supprimer
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="custom-card-body p-3">
                    <?php if (!empty($cat['description'])): ?>
                        <p class="text-muted small mb-3"><?= sanitize($cat['description']) ?></p>
                    <?php endif; ?>

                    <div class="fw-bold text-dark small mb-2 d-flex justify-content-between align-items-center">
                        <span>Sous-catégories (<?= count($cat['subcategories']) ?>)</span>
                        <button class="btn btn-sm text-success p-0" data-bs-toggle="modal" data-bs-target="#addSubcategoryModal<?= $cat['id'] ?>" title="Ajouter">
                            <i class="bi bi-plus-circle-fill"></i>
                        </button>
                    </div>

                    <div class="d-flex flex-wrap gap-2 mb-2">
                        <?php if (empty($cat['subcategories'])): ?>
                            <span class="text-muted small fst-italic">Aucune sous-catégorie</span>
                        <?php else: ?>
                            <?php foreach ($cat['subcategories'] as $sub): ?>
                                <span class="badge bg-light text-dark border p-2 d-inline-flex align-items-center gap-2">
                                    <?= sanitize($sub['name']) ?>
                                    <form action="index.php?page=categories&action=subcategory_delete" method="POST" class="d-inline" onsubmit="return confirm('Supprimer cette sous-catégorie ?');">
                                        <input type="hidden" name="id" value="<?= $sub['id'] ?>">
                                        <button type="submit" class="btn-close" style="font-size: 8px;" aria-label="Supprimer"></button>
                                    </form>
                                </span>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Category Modal -->
        <div class="modal fade" id="editCategoryModal<?= $cat['id'] ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg rounded-4">
                    <form action="index.php?page=categories&action=update" method="POST">
                        <input type="hidden" name="id" value="<?= $cat['id'] ?>">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold">Modifier Catégorie</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Nom</label>
                                <input type="text" name="name" class="form-control" value="<?= sanitize($cat['name']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Icône Bootstrap</label>
                                <input type="text" name="icon" class="form-control" value="<?= sanitize($cat['icon']) ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Description</label>
                                <textarea name="description" class="form-control" rows="2"><?= sanitize($cat['description']) ?></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-brand">Enregistrer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Add Subcategory Modal -->
        <div class="modal fade" id="addSubcategoryModal<?= $cat['id'] ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg rounded-4">
                    <form action="index.php?page=categories&action=subcategory_store" method="POST">
                        <input type="hidden" name="category_id" value="<?= $cat['id'] ?>">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold">Ajouter sous-catégorie à <?= sanitize($cat['name']) ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Nom de la sous-catégorie</label>
                                <input type="text" name="name" class="form-control" placeholder="Ex: Lait UHT, Pâtes Courtes..." required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-brand">Ajouter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Add Category Modal -->
<div class="modal fade" id="addCategoryModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form action="index.php?page=categories&action=store" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Nouvelle Catégorie</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nom de la catégorie <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="Ex: Surgelés" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Icône Bootstrap</label>
                        <input type="text" name="icon" class="form-control" placeholder="bi-snow" value="bi-box-seam">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Description</label>
                        <textarea name="description" class="form-control" rows="2" placeholder="Description des produits..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-brand">Créer la catégorie</button>
                </div>
            </form>
        </div>
    </div>
</div>
