<?php
/**
 * Settings View
 */
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Paramètres du Système</h1>
        <p class="page-subtitle">Configurez le comparateur SuperSoum et gérez votre compte administrateur.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: System & Comparison Settings -->
    <div class="col-lg-7">
        <div class="custom-card mb-4">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-sliders text-success"></i>
                    <span>Configuration Comparateur</span>
                </h3>
            </div>
            <div class="custom-card-body">
                <form action="index.php?page=settings&action=update" method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nom de la plateforme</label>
                        <input type="text" name="site_name" class="form-control" value="<?= sanitize($settings['site_name'] ?? 'SuperSoum') ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Slogan</label>
                        <input type="text" name="site_tagline" class="form-control" value="<?= sanitize($settings['site_tagline'] ?? 'Le 1er comparateur de prix en Tunisie') ?>">
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Email de contact</label>
                            <input type="email" name="contact_email" class="form-control" value="<?= sanitize($settings['contact_email'] ?? 'contact@supersoum.tn') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Devise</label>
                            <input type="text" name="currency" class="form-control" value="<?= sanitize($settings['currency'] ?? 'DT') ?>" readonly>
                        </div>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Articles par page (Pagination)</label>
                            <input type="number" name="items_per_page" class="form-control" value="<?= sanitize($settings['items_per_page'] ?? '10') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Alerte Écart de Prix (%)</label>
                            <input type="number" name="alert_price_variation" class="form-control" value="<?= sanitize($settings['alert_price_variation'] ?? '15') ?>">
                        </div>
                    </div>

                    <div class="p-3 bg-light rounded-3 mb-4 d-flex flex-column gap-3 border">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="auto_best_price" id="auto_best_price" value="1" <?= ($settings['auto_best_price'] ?? '1') == '1' ? 'checked' : '' ?>>
                            <label class="form-check-label small fw-semibold" for="auto_best_price">
                                Calcul dynamique automatique du Meilleur Prix en temps réel
                            </label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="notify_promo_expiring" id="notify_promo_expiring" value="1" <?= ($settings['notify_promo_expiring'] ?? '1') == '1' ? 'checked' : '' ?>>
                            <label class="form-check-label small fw-semibold" for="notify_promo_expiring">
                                Notifications d'expiration des promotions
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-brand">
                        <i class="bi bi-check-circle-fill me-1"></i> Enregistrer les Paramètres
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Right Column: Admin Profile & Password -->
    <div class="col-lg-5">
        <!-- Admin Profile -->
        <div class="custom-card mb-4">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-person-gear text-primary"></i>
                    <span>Profil Administrateur</span>
                </h3>
            </div>
            <div class="custom-card-body">
                <form action="index.php?page=settings&action=update_profile" method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nom complet</label>
                        <input type="text" name="full_name" class="form-control" value="<?= sanitize($currentAdmin['full_name'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Adresse Email</label>
                        <input type="email" name="email" class="form-control" value="<?= sanitize($currentAdmin['email'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Identifiant</label>
                        <input type="text" class="form-control" value="<?= sanitize($currentAdmin['username'] ?? '') ?>" readonly>
                    </div>

                    <button type="submit" class="btn btn-brand-outline w-100">
                        <i class="bi bi-save me-1"></i> Mettre à jour le Profil
                    </button>
                </form>
            </div>
        </div>

        <!-- Password Change -->
        <div class="custom-card">
            <div class="custom-card-header">
                <h3 class="custom-card-title">
                    <i class="bi bi-key-fill text-warning"></i>
                    <span>Modifier le Mot de Passe</span>
                </h3>
            </div>
            <div class="custom-card-body">
                <form action="index.php?page=settings&action=update_password" method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Mot de passe actuel</label>
                        <input type="password" name="current_password" class="form-control" placeholder="••••••••" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nouveau mot de passe</label>
                        <input type="password" name="new_password" class="form-control" placeholder="••••••••" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Confirmer nouveau mot de passe</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="••••••••" required>
                    </div>

                    <button type="submit" class="btn btn-light border text-dark fw-bold w-100">
                        <i class="bi bi-shield-lock me-1"></i> Changer le mot de passe
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
