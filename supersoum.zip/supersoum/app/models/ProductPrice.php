<?php
/**
 * ProductPrice Model
 */
require_once __DIR__ . '/../../config/database.php';

class ProductPrice {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function savePrice(int $productId, int $supermarketId, float $price, int $inStock = 1): bool {
        // Upsert into product_prices
        $sql = "
            INSERT INTO product_prices (product_id, supermarket_id, price, in_stock, last_updated)
            VALUES (:product_id, :supermarket_id, :price, :in_stock, NOW())
            ON DUPLICATE KEY UPDATE 
                price = VALUES(price),
                in_stock = VALUES(in_stock),
                last_updated = NOW()
        ";
        $stmt = $this->db->prepare($sql);
        $res = $stmt->execute([
            ':product_id' => $productId,
            ':supermarket_id' => $supermarketId,
            ':price' => $price,
            ':in_stock' => $inStock
        ]);

        if ($res) {
            // Also log into price_history
            $this->recordHistory($productId, $supermarketId, $price);
        }

        return $res;
    }

    public function saveAllPricesForProduct(int $productId, array $prices): bool {
        foreach ($prices as $marketId => $priceData) {
            $price = $priceData['price'] ?? null;
            $inStock = isset($priceData['in_stock']) ? 1 : 0;
            
            if ($price !== '' && $price !== null && (float)$price > 0) {
                $this->savePrice($productId, (int)$marketId, (float)$price, $inStock);
            } else {
                $this->deletePrice($productId, (int)$marketId);
            }
        }
        return true;
    }

    public function deletePrice(int $productId, int $supermarketId): bool {
        $stmt = $this->db->prepare("DELETE FROM product_prices WHERE product_id = :prod_id AND supermarket_id = :market_id");
        return $stmt->execute([':prod_id' => $productId, ':market_id' => $supermarketId]);
    }

    public function recordHistory(int $productId, int $supermarketId, float $price): void {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO price_history (product_id, supermarket_id, price, recorded_date)
                VALUES (:prod_id, :market_id, :price, CURDATE())
            ");
            $stmt->execute([
                ':prod_id' => $productId,
                ':market_id' => $supermarketId,
                ':price' => $price
            ]);
        } catch (Exception $e) {
            // Ignore duplicate history for today
        }
    }

    public function getRecentUpdates(int $limit = 6): array {
        $stmt = $this->db->prepare("
            SELECT pp.*, p.name as product_name, p.image as product_image, s.name as supermarket_name, s.logo as supermarket_logo, s.color_hex
            FROM product_prices pp
            JOIN products p ON pp.product_id = p.id
            JOIN supermarkets s ON pp.supermarket_id = s.id
            ORDER BY pp.last_updated DESC
            LIMIT :limit
        ");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function countUpdatedRecently(): int {
        $stmt = $this->db->query("SELECT COUNT(*) FROM product_prices WHERE last_updated >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
        return (int)$stmt->fetchColumn();
    }

    public function getMonthlyEvolution(): array {
        // Retrieve average prices per month across supermarkets
        $sql = "
            SELECT DATE_FORMAT(recorded_date, '%b %Y') as month_label,
                   AVG(price) as avg_price,
                   MIN(price) as min_price,
                   MAX(price) as max_price
            FROM price_history
            GROUP BY DATE_FORMAT(recorded_date, '%Y-%m'), DATE_FORMAT(recorded_date, '%b %Y')
            ORDER BY recorded_date ASC
            LIMIT 6
        ";
        return $this->db->query($sql)->fetchAll();
    }
}
