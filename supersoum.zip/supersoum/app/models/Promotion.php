<?php
/**
 * Promotion Model
 */
require_once __DIR__ . '/../../config/database.php';

class Promotion {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(bool $onlyActive = false): array {
        $sql = "
            SELECT pr.*, 
                   p.name as product_name, p.image as product_image, p.unit as product_unit,
                   c.name as category_name,
                   s.name as supermarket_name, s.logo as supermarket_logo, s.color_hex
            FROM promotions pr
            JOIN products p ON pr.product_id = p.id
            LEFT JOIN categories c ON p.category_id = c.id
            JOIN supermarkets s ON pr.supermarket_id = s.id
        ";
        if ($onlyActive) {
            $sql .= " WHERE pr.active = 1 AND pr.end_date >= CURDATE() AND pr.start_date <= CURDATE()";
        }
        $sql .= " ORDER BY pr.active DESC, pr.end_date ASC, pr.discount_percentage DESC";

        return $this->db->query($sql)->fetchAll();
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("
            SELECT pr.*, p.name as product_name, s.name as supermarket_name 
            FROM promotions pr
            JOIN products p ON pr.product_id = p.id
            JOIN supermarkets s ON pr.supermarket_id = s.id
            WHERE pr.id = :id
        ");
        $stmt->execute([':id' => $id]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public function create(array $data): int {
        $orig = (float)$data['original_price'];
        $promo = (float)$data['promo_price'];
        $discount = (int)($data['discount_percentage'] ?? 0);

        if ($discount <= 0 && $orig > 0 && $promo > 0) {
            $discount = (int)round((($orig - $promo) / $orig) * 100);
        } elseif ($promo <= 0 && $orig > 0 && $discount > 0) {
            $promo = round($orig * (1 - ($discount / 100)), 3);
        }

        $stmt = $this->db->prepare("
            INSERT INTO promotions (product_id, supermarket_id, original_price, promo_price, discount_percentage, title, start_date, end_date, active)
            VALUES (:prod_id, :market_id, :orig, :promo, :discount, :title, :start, :end, :active)
        ");
        $stmt->execute([
            ':prod_id' => (int)$data['product_id'],
            ':market_id' => (int)$data['supermarket_id'],
            ':orig' => $orig,
            ':promo' => $promo,
            ':discount' => $discount,
            ':title' => $data['title'] ?? null,
            ':start' => $data['start_date'],
            ':end' => $data['end_date'],
            ':active' => isset($data['active']) ? (int)$data['active'] : 1
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool {
        $orig = (float)$data['original_price'];
        $promo = (float)$data['promo_price'];
        $discount = (int)($data['discount_percentage'] ?? 0);

        if ($discount <= 0 && $orig > 0 && $promo > 0) {
            $discount = (int)round((($orig - $promo) / $orig) * 100);
        } elseif ($promo <= 0 && $orig > 0 && $discount > 0) {
            $promo = round($orig * (1 - ($discount / 100)), 3);
        }

        $stmt = $this->db->prepare("
            UPDATE promotions 
            SET product_id = :prod_id, supermarket_id = :market_id, 
                original_price = :orig, promo_price = :promo, discount_percentage = :discount, 
                title = :title, start_date = :start, end_date = :end, active = :active
            WHERE id = :id
        ");
        return $stmt->execute([
            ':prod_id' => (int)$data['product_id'],
            ':market_id' => (int)$data['supermarket_id'],
            ':orig' => $orig,
            ':promo' => $promo,
            ':discount' => $discount,
            ':title' => $data['title'] ?? null,
            ':start' => $data['start_date'],
            ':end' => $data['end_date'],
            ':active' => isset($data['active']) ? (int)$data['active'] : 1,
            ':id' => $id
        ]);
    }

    public function delete(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM promotions WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function countActive(): int {
        $sql = "SELECT COUNT(*) FROM promotions WHERE active = 1 AND end_date >= CURDATE() AND start_date <= CURDATE()";
        return (int)$this->db->query($sql)->fetchColumn();
    }

    public function getPromotionsBySupermarket(): array {
        $sql = "
            SELECT s.name as supermarket_name, s.color_hex, COUNT(pr.id) as promo_count
            FROM supermarkets s
            LEFT JOIN promotions pr ON s.id = pr.supermarket_id AND pr.active = 1 AND pr.end_date >= CURDATE()
            WHERE s.active = 1
            GROUP BY s.id
            ORDER BY s.id ASC
        ";
        return $this->db->query($sql)->fetchAll();
    }
}
