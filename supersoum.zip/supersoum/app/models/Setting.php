<?php
/**
 * Setting Model
 */
require_once __DIR__ . '/../../config/database.php';

class Setting {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(): array {
        $stmt = $this->db->query("SELECT setting_key, setting_value FROM settings");
        $results = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        return $results ?: [];
    }

    public function get(string $key, $default = null) {
        $stmt = $this->db->prepare("SELECT setting_value FROM settings WHERE setting_key = :key");
        $stmt->execute([':key' => $key]);
        $val = $stmt->fetchColumn();
        return $val !== false ? $val : $default;
    }

    public function set(string $key, $value): bool {
        $stmt = $this->db->prepare("
            INSERT INTO settings (setting_key, setting_value, updated_at) 
            VALUES (:key, :val, NOW())
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
        ");
        return $stmt->execute([':key' => $key, ':val' => $value]);
    }

    public function updateMultiple(array $settings): bool {
        foreach ($settings as $k => $v) {
            $this->set($k, $v);
        }
        return true;
    }
}
