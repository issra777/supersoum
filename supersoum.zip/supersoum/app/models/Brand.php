<?php
/**
 * Brand Model
 */
require_once __DIR__ . '/../../config/database.php';

class Brand {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(): array {
        $sql = "
            SELECT b.*, COUNT(p.id) as products_count 
            FROM brands b 
            LEFT JOIN products p ON b.id = p.brand_id 
            GROUP BY b.id 
            ORDER BY b.name ASC
        ";
        return $this->db->query($sql)->fetchAll();
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("SELECT * FROM brands WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public function create(array $data): int {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['name'])));
        $stmt = $this->db->prepare("
            INSERT INTO brands (name, slug, logo, origin) 
            VALUES (:name, :slug, :logo, :origin)
        ");
        $stmt->execute([
            ':name' => $data['name'],
            ':slug' => $slug,
            ':logo' => $data['logo'] ?? null,
            ':origin' => $data['origin'] ?? 'Tunisie'
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['name'])));
        $stmt = $this->db->prepare("
            UPDATE brands 
            SET name = :name, slug = :slug, logo = :logo, origin = :origin 
            WHERE id = :id
        ");
        return $stmt->execute([
            ':name' => $data['name'],
            ':slug' => $slug,
            ':logo' => $data['logo'] ?? null,
            ':origin' => $data['origin'] ?? 'Tunisie',
            ':id' => $id
        ]);
    }

    public function delete(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM brands WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}
