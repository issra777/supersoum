<?php
/**
 * Subcategory Model
 */
require_once __DIR__ . '/../../config/database.php';

class Subcategory {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(): array {
        $stmt = $this->db->query("
            SELECT sc.*, c.name as category_name 
            FROM subcategories sc 
            JOIN categories c ON sc.category_id = c.id 
            ORDER BY c.name ASC, sc.name ASC
        ");
        return $stmt->fetchAll();
    }

    public function getByCategoryId(int $categoryId): array {
        $stmt = $this->db->prepare("SELECT * FROM subcategories WHERE category_id = :cat_id ORDER BY name ASC");
        $stmt->execute([':cat_id' => $categoryId]);
        return $stmt->fetchAll();
    }

    public function create(int $categoryId, string $name): int {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
        $stmt = $this->db->prepare("INSERT INTO subcategories (category_id, name, slug) VALUES (:cat_id, :name, :slug)");
        $stmt->execute([':cat_id' => $categoryId, ':name' => $name, ':slug' => $slug]);
        return (int)$this->db->lastInsertId();
    }

    public function delete(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM subcategories WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}
