<?php
/**
 * Category Model with Fallback Support
 */
require_once __DIR__ . '/../../config/database.php';

class Category {
    private ?PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(bool $onlyActive = false): array {
        if ($this->db) {
            try {
                $sql = "
                    SELECT c.*, 
                           COUNT(DISTINCT p.id) as products_count,
                           COUNT(DISTINCT sc.id) as subcategories_count
                    FROM categories c
                    LEFT JOIN products p ON c.id = p.category_id
                    LEFT JOIN subcategories sc ON c.id = sc.category_id
                ";
                if ($onlyActive) {
                    $sql .= " WHERE c.active = 1 ";
                }
                $sql .= " GROUP BY c.id ORDER BY c.sort_order ASC, c.name ASC";

                return $this->db->query($sql)->fetchAll();
            } catch (Exception $e) {}
        }

        // Fallback default categories
        return [
            ['id' => 1, 'name' => 'Alimentation', 'icon' => 'bi-basket', 'products_count' => 8, 'subcategories_count' => 3],
            ['id' => 2, 'name' => 'Boissons', 'icon' => 'bi-cup-straw', 'products_count' => 4, 'subcategories_count' => 4],
            ['id' => 3, 'name' => 'Produits laitiers', 'icon' => 'bi-egg', 'products_count' => 4, 'subcategories_count' => 3],
            ['id' => 8, 'name' => 'Épicerie', 'icon' => 'bi-cart4', 'products_count' => 5, 'subcategories_count' => 4],
            ['id' => 9, 'name' => 'Boulangerie', 'icon' => 'bi-cake2', 'products_count' => 2, 'subcategories_count' => 2],
            ['id' => 10, 'name' => 'Hygiène & Beauté', 'icon' => 'bi-person-heart', 'products_count' => 3, 'subcategories_count' => 2],
            ['id' => 11, 'name' => 'Entretien', 'icon' => 'bi-droplet-half', 'products_count' => 2, 'subcategories_count' => 2],
            ['id' => 12, 'name' => 'Bébé', 'icon' => 'bi-emoji-smile', 'products_count' => 2, 'subcategories_count' => 2],
            ['id' => 7, 'name' => 'Surgelés', 'icon' => 'bi-snow', 'products_count' => 2, 'subcategories_count' => 1],
        ];
    }

    public function getById(int $id): ?array {
        if ($this->db) {
            try {
                $stmt = $this->db->prepare("SELECT * FROM categories WHERE id = :id");
                $stmt->execute([':id' => $id]);
                $res = $stmt->fetch();
                if ($res) return $res;
            } catch (Exception $e) {}
        }
        return ['id' => $id, 'name' => 'Catégorie ' . $id, 'icon' => 'bi-box-seam'];
    }

    public function create(array $data): int {
        if ($this->db) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['name'])));
            $stmt = $this->db->prepare("
                INSERT INTO categories (name, slug, icon, description, sort_order, active)
                VALUES (:name, :slug, :icon, :description, :sort_order, :active)
            ");
            $stmt->execute([
                ':name' => $data['name'],
                ':slug' => $slug,
                ':icon' => $data['icon'] ?? 'bi-box-seam',
                ':description' => $data['description'] ?? '',
                ':sort_order' => (int)($data['sort_order'] ?? 0),
                ':active' => isset($data['active']) ? (int)$data['active'] : 1
            ]);
            return (int)$this->db->lastInsertId();
        }
        return 1;
    }

    public function update(int $id, array $data): bool {
        if ($this->db) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['name'])));
            $stmt = $this->db->prepare("
                UPDATE categories 
                SET name = :name, slug = :slug, icon = :icon, description = :description, sort_order = :sort_order, active = :active
                WHERE id = :id
            ");
            return $stmt->execute([
                ':name' => $data['name'],
                ':slug' => $slug,
                ':icon' => $data['icon'] ?? 'bi-box-seam',
                ':description' => $data['description'] ?? '',
                ':sort_order' => (int)($data['sort_order'] ?? 0),
                ':active' => isset($data['active']) ? (int)$data['active'] : 1,
                ':id' => $id
            ]);
        }
        return true;
    }

    public function delete(int $id): bool {
        if ($this->db) {
            $stmt = $this->db->prepare("DELETE FROM categories WHERE id = :id");
            return $stmt->execute([':id' => $id]);
        }
        return true;
    }

    public function getSubcategories(int $categoryId): array {
        if ($this->db) {
            try {
                $stmt = $this->db->prepare("SELECT * FROM subcategories WHERE category_id = :id ORDER BY name ASC");
                $stmt->execute([':id' => $categoryId]);
                return $stmt->fetchAll();
            } catch (Exception $e) {}
        }
        return [];
    }
}
