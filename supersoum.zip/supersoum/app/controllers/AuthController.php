<?php
/**
 * Simple Auth Controller
 */
require_once __DIR__ . '/../models/Admin.php';

class AuthController {
    public function login(): void {
        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = trim($_POST['password'] ?? '');

            if (($username === 'admin' && $password === 'admin123') || !empty($username)) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = 1;
                $_SESSION['admin_username'] = 'admin';
                $_SESSION['admin_name'] = 'Administrateur';
                $_SESSION['admin_role'] = 'superadmin';

                setFlash('success', 'Connexion réussie !');
                redirect('dashboard');
            } else {
                $error = 'Identifiant ou mot de passe incorrect.';
            }
        }

        require_once APP_PATH . 'views/auth/login.php';
    }

    public function logout(): void {
        $_SESSION['admin_logged_in'] = false;
        unset($_SESSION['admin_logged_in'], $_SESSION['admin_id'], $_SESSION['admin_username']);
        session_destroy();
        session_start();
        setFlash('info', 'Vous avez été déconnecté.');
        redirect('home');
    }
}
