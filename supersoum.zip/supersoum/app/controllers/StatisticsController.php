<?php
/**
 * Statistics Controller
 */
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Supermarket.php';
require_once __DIR__ . '/../models/Promotion.php';
require_once __DIR__ . '/../models/ProductPrice.php';

class StatisticsController {
    private Product $productModel;
    private Category $categoryModel;
    private Supermarket $supermarketModel;
    private Promotion $promotionModel;
    private ProductPrice $priceModel;

    public function __construct() {
        requireAuth();
        $this->productModel = new Product();
        $this->categoryModel = new Category();
        $this->supermarketModel = new Supermarket();
        $this->promotionModel = new Promotion();
        $this->priceModel = new ProductPrice();
    }

    public function index(): void {
        $supermarkets = $this->supermarketModel->getAll(true);
        $categories = $this->categoryModel->getAll(true);
        $totalProducts = $this->productModel->countTotal();
        $activePromos = $this->promotionModel->countActive();

        // Calculate Average Basket Value per Supermarket (Simulated standard shopping basket)
        $basketComparison = [];
        foreach ($supermarkets as $market) {
            $avgPrice = (float)($market['avg_price_level'] ?? 0);
            $totalPriced = (int)($market['total_products_priced'] ?? 0);
            $basketComparison[] = [
                'name' => $market['name'],
                'color' => $market['color_hex'],
                'avg_price' => $avgPrice,
                'total_priced' => $totalPriced,
                'promos' => (int)($market['active_promos_count'] ?? 0),
                'basket_total' => $avgPrice * 10 // 10 typical items
            ];
        }

        // Sort by cheapest basket
        usort($basketComparison, function($a, $b) {
            return $a['basket_total'] <=> $b['basket_total'];
        });

        // Category distribution data
        $catData = $this->productModel->getCategoryDistribution();

        // Supermarkets promo share data
        $promoData = $this->promotionModel->getPromotionsBySupermarket();

        // Monthly evolution
        $evolutionData = $this->priceModel->getMonthlyEvolution();

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/statistics/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }
}
