<?php
/**
 * Home Controller - Public Frontend Comparator
 * Matching the clean, modern style requested by user
 */
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Supermarket.php';
require_once __DIR__ . '/../models/Promotion.php';
require_once __DIR__ . '/../models/ProductPrice.php';

class HomeController {
    private Product $productModel;
    private Category $categoryModel;
    private Supermarket $supermarketModel;
    private Promotion $promotionModel;

    public function __construct() {
        $this->productModel = new Product();
        $this->categoryModel = new Category();
        $this->supermarketModel = new Supermarket();
        $this->promotionModel = new Promotion();
    }

    public function index(): void {
        $categories = $this->categoryModel->getAll(true);
        $supermarkets = $this->supermarketModel->getAll(true);

        // Filter / Search
        $search = trim($_GET['search'] ?? '');
        $categoryId = !empty($_GET['category']) ? (int)$_GET['category'] : null;

        // Active / Featured Product for the big comparison card
        $selectedProductId = !empty($_GET['product_id']) ? (int)$_GET['product_id'] : 1;
        $selectedProduct = $this->productModel->getById($selectedProductId);
        
        // If not found, get first product
        if (!$selectedProduct) {
            $allProds = $this->productModel->getAll([], 1, 0);
            if (!empty($allProds)) {
                $selectedProduct = $allProds[0];
                $selectedProductId = (int)$selectedProduct['id'];
            }
        }

        // Fetch prices for selected product across all 5 supermarkets
        $selectedPrices = [];
        $minPrice = null;
        $maxPrice = null;
        $bestMarket = null;

        if ($selectedProduct) {
            $pricesList = $this->productModel->getPrices($selectedProductId);
            foreach ($pricesList as $p) {
                $selectedPrices[$p['supermarket_id']] = $p;
                if ($p['effective_price'] !== null && (float)$p['effective_price'] > 0) {
                    $eff = (float)$p['effective_price'];
                    if ($minPrice === null || $eff < $minPrice) {
                        $minPrice = $eff;
                        $bestMarket = $p['supermarket_name'];
                    }
                    if ($maxPrice === null || $eff > $maxPrice) {
                        $maxPrice = $eff;
                    }
                }
            }
        }

        $savings = ($maxPrice !== null && $minPrice !== null) ? ($maxPrice - $minPrice) : 0;

        // Popular products list for bottom cards
        $popularFilters = [];
        if ($categoryId) {
            $popularFilters['category_id'] = $categoryId;
        }
        if ($search) {
            $popularFilters['search'] = $search;
        }

        $popularProducts = $this->productModel->getAll($popularFilters, 12, 0);
        foreach ($popularProducts as &$pop) {
            $pop['prices'] = $this->productModel->getPrices((int)$pop['id']);
        }

        require_once APP_PATH . 'views/home/index.php';
    }
}
