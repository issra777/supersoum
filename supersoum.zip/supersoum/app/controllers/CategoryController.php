<?php
/**
 * Category Controller
 */
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Subcategory.php';
require_once __DIR__ . '/../models/Admin.php';

class CategoryController {
    private Category $categoryModel;
    private Subcategory $subcategoryModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->categoryModel = new Category();
        $this->subcategoryModel = new Subcategory();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        $categories = $this->categoryModel->getAll();
        
        // Add subcategories list to each category
        foreach ($categories as &$cat) {
            $cat['subcategories'] = $this->categoryModel->getSubcategories((int)$cat['id']);
        }

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/categories/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function store(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            if (!empty($name)) {
                $id = $this->categoryModel->create([
                    'name' => $name,
                    'icon' => $_POST['icon'] ?? 'bi-box-seam',
                    'description' => trim($_POST['description'] ?? ''),
                    'sort_order' => (int)($_POST['sort_order'] ?? 0),
                    'active' => isset($_POST['active']) ? 1 : 0
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'AJOUT_CATEGORIE', "Création de la catégorie $name");
                setFlash('success', "Catégorie '$name' créée avec succès !");
            } else {
                setFlash('danger', 'Le nom de la catégorie est obligatoire.');
            }
        }
        redirect('categories');
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            if ($id > 0 && !empty($name)) {
                $this->categoryModel->update($id, [
                    'name' => $name,
                    'icon' => $_POST['icon'] ?? 'bi-box-seam',
                    'description' => trim($_POST['description'] ?? ''),
                    'sort_order' => (int)($_POST['sort_order'] ?? 0),
                    'active' => isset($_POST['active']) ? 1 : 0
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'MODIF_CATEGORIE', "Mise à jour de la catégorie $name");
                setFlash('success', "Catégorie '$name' mise à jour !");
            } else {
                setFlash('danger', 'Informations de catégorie invalides.');
            }
        }
        redirect('categories');
    }

    public function delete(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                try {
                    $this->categoryModel->delete($id);
                    $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'SUPPRESSION_CATEGORIE', "Suppression catégorie ID #$id");
                    setFlash('success', 'Catégorie supprimée avec succès.');
                } catch (Exception $e) {
                    setFlash('danger', 'Impossible de supprimer cette catégorie car des produits y sont associés.');
                }
            }
        }
        redirect('categories');
    }

    public function subcategoryStore(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $catId = (int)($_POST['category_id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            if ($catId > 0 && !empty($name)) {
                $this->subcategoryModel->create($catId, $name);
                setFlash('success', "Sous-catégorie '$name' ajoutée !");
            }
        }
        redirect('categories');
    }

    public function subcategoryDelete(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $this->subcategoryModel->delete($id);
                setFlash('success', 'Sous-catégorie supprimée.');
            }
        }
        redirect('categories');
    }
}
