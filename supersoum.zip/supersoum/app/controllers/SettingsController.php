<?php
/**
 * Settings Controller
 */
require_once __DIR__ . '/../models/Setting.php';
require_once __DIR__ . '/../models/Admin.php';

class SettingsController {
    private Setting $settingModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->settingModel = new Setting();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        $settings = $this->settingModel->getAll();
        $currentAdmin = $this->adminModel->getById((int)$_SESSION['admin_id']);

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/settings/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $settingsData = [
                'site_name'              => trim($_POST['site_name'] ?? 'SuperSoum'),
                'site_tagline'           => trim($_POST['site_tagline'] ?? ''),
                'contact_email'          => trim($_POST['contact_email'] ?? ''),
                'currency'               => trim($_POST['currency'] ?? 'DT'),
                'currency_symbol'        => trim($_POST['currency_symbol'] ?? 'DT'),
                'auto_best_price'        => isset($_POST['auto_best_price']) ? '1' : '0',
                'notify_promo_expiring'  => isset($_POST['notify_promo_expiring']) ? '1' : '0',
                'items_per_page'         => (string)(int)($_POST['items_per_page'] ?? 10),
                'alert_price_variation'  => (string)(int)($_POST['alert_price_variation'] ?? 15),
                'maintenance_mode'       => isset($_POST['maintenance_mode']) ? '1' : '0'
            ];

            $this->settingModel->updateMultiple($settingsData);
            $this->adminModel->logActivity($_SESSION['admin_id'], 'MAJ_PARAMETRES', 'Mise à jour des paramètres système');

            setFlash('success', 'Paramètres système enregistrés avec succès !');
        }
        redirect('settings');
    }

    public function updateProfile(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $adminId = (int)$_SESSION['admin_id'];
            $fullName = trim($_POST['full_name'] ?? '');
            $email = trim($_POST['email'] ?? '');

            if (!empty($fullName) && !empty($email)) {
                $this->adminModel->updateProfile($adminId, $fullName, $email);
                $_SESSION['admin_name'] = $fullName;
                setFlash('success', 'Votre profil administrateur a été mis à jour.');
            } else {
                setFlash('danger', 'Veuillez remplir tous les champs du profil.');
            }
        }
        redirect('settings');
    }

    public function updatePassword(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $adminId = (int)$_SESSION['admin_id'];
            $currentPass = trim($_POST['current_password'] ?? '');
            $newPass = trim($_POST['new_password'] ?? '');
            $confirmPass = trim($_POST['confirm_password'] ?? '');

            if (empty($newPass) || strlen($newPass) < 6) {
                setFlash('danger', 'Le nouveau mot de passe doit comporter au moins 6 caractères.');
                redirect('settings');
            }

            if ($newPass !== $confirmPass) {
                setFlash('danger', 'Les nouveaux mots de passe ne correspondent pas.');
                redirect('settings');
            }

            // Verify current password
            $admin = $this->adminModel->authenticate($_SESSION['admin_username'], $currentPass);
            if (!$admin) {
                setFlash('danger', 'Le mot de passe actuel est incorrect.');
                redirect('settings');
            }

            $this->adminModel->updatePassword($adminId, $newPass);
            $this->adminModel->logActivity($adminId, 'CHANGEMENT_MDP', 'Changement réussi du mot de passe administrateur');
            setFlash('success', 'Votre mot de passe a été modifié avec succès.');
        }
        redirect('settings');
    }
}
