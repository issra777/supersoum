<?php
/**
 * User Controller
 */
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Admin.php';

class UserController {
    private User $userModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->userModel = new User();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        $users = $this->userModel->getAll();

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/users/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function store(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');

            if (!empty($name) && !empty($email)) {
                $this->userModel->create([
                    'name'        => $name,
                    'email'       => $email,
                    'phone'       => trim($_POST['phone'] ?? ''),
                    'governorate' => $_POST['governorate'] ?? 'Tunis',
                    'status'      => $_POST['status'] ?? 'active'
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'AJOUT_UTILISATEUR', "Ajout utilisateur $name ($email)");
                setFlash('success', "Utilisateur '$name' créé avec succès !");
            } else {
                setFlash('danger', 'Le nom et l\'email sont requis.');
            }
        }
        redirect('users');
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');

            if ($id > 0 && !empty($name) && !empty($email)) {
                $this->userModel->update($id, [
                    'name'        => $name,
                    'email'       => $email,
                    'phone'       => trim($_POST['phone'] ?? ''),
                    'governorate' => $_POST['governorate'] ?? 'Tunis',
                    'status'      => $_POST['status'] ?? 'active'
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'MODIF_UTILISATEUR', "Mise à jour utilisateur #$id");
                setFlash('success', 'Utilisateur mis à jour !');
            }
        }
        redirect('users');
    }

    public function delete(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $this->userModel->delete($id);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'SUPPR_UTILISATEUR', "Suppression utilisateur #$id");
                setFlash('success', 'Utilisateur supprimé.');
            }
        }
        redirect('users');
    }
}
