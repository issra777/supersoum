<?php
/**
 * Price Controller
 */
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Supermarket.php';
require_once __DIR__ . '/../models/ProductPrice.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Admin.php';

class PriceController {
    private Product $productModel;
    private Supermarket $supermarketModel;
    private ProductPrice $priceModel;
    private Category $categoryModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->productModel = new Product();
        $this->supermarketModel = new Supermarket();
        $this->priceModel = new ProductPrice();
        $this->categoryModel = new Category();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        $filters = [
            'search'      => trim($_GET['search'] ?? ''),
            'category_id' => $_GET['category_id'] ?? '',
            'sort'        => $_GET['sort'] ?? 'name_asc',
        ];

        $page = max(1, (int)($_GET['p'] ?? 1));
        $limit = 15;
        $offset = ($page - 1) * $limit;

        $totalProducts = $this->productModel->countFiltered($filters);
        $totalPages = max(1, ceil($totalProducts / $limit));
        $products = $this->productModel->getAll($filters, $limit, $offset);

        // Fetch prices matrix for each product
        foreach ($products as &$p) {
            $p['prices_by_market'] = [];
            $pricesList = $this->productModel->getPrices((int)$p['id']);
            foreach ($pricesList as $pr) {
                $p['prices_by_market'][$pr['supermarket_id']] = $pr;
            }
        }

        $supermarkets = $this->supermarketModel->getAll(true);
        $categories = $this->categoryModel->getAll(true);

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/prices/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $productId = (int)($_POST['product_id'] ?? 0);
            $prices = $_POST['prices'] ?? [];

            if ($productId > 0 && is_array($prices)) {
                $this->priceModel->saveAllPricesForProduct($productId, $prices);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'MAJ_PRIX', "Mise à jour des prix pour le produit #$productId");
                setFlash('success', 'Prix mis à jour avec succès !');
            } else {
                setFlash('danger', 'Données de prix invalides.');
            }
        }
        redirect('prices');
    }
}
