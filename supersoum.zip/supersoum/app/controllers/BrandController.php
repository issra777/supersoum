<?php
/**
 * Brand Controller
 */
require_once __DIR__ . '/../models/Brand.php';
require_once __DIR__ . '/../models/Admin.php';

class BrandController {
    private Brand $brandModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->brandModel = new Brand();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        $brands = $this->brandModel->getAll();

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/brands/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function store(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            if (!empty($name)) {
                $this->brandModel->create([
                    'name'   => $name,
                    'origin' => trim($_POST['origin'] ?? 'Tunisie')
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'AJOUT_MARQUE', "Ajout de la marque $name");
                setFlash('success', "Marque '$name' ajoutée avec succès !");
            } else {
                setFlash('danger', 'Le nom de la marque est obligatoire.');
            }
        }
        redirect('brands');
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            if ($id > 0 && !empty($name)) {
                $this->brandModel->update($id, [
                    'name'   => $name,
                    'origin' => trim($_POST['origin'] ?? 'Tunisie')
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'MODIF_MARQUE', "Mise à jour de la marque $name");
                setFlash('success', "Marque '$name' mise à jour !");
            }
        }
        redirect('brands');
    }

    public function delete(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $this->brandModel->delete($id);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'SUPPR_MARQUE', "Suppression marque ID #$id");
                setFlash('success', 'Marque supprimée avec succès.');
            }
        }
        redirect('brands');
    }
}
