<?php
/**
 * Supermarket Controller
 */
require_once __DIR__ . '/../models/Supermarket.php';
require_once __DIR__ . '/../models/Admin.php';

class SupermarketController {
    private Supermarket $supermarketModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->supermarketModel = new Supermarket();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        $supermarkets = $this->supermarketModel->getAll();

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/supermarkets/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function store(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            if (!empty($name)) {
                $this->supermarketModel->create([
                    'name'         => $name,
                    'color_hex'    => $_POST['color_hex'] ?? '#16A34A',
                    'website'      => trim($_POST['website'] ?? ''),
                    'stores_count' => (int)($_POST['stores_count'] ?? 1),
                    'active'       => isset($_POST['active']) ? 1 : 0
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'AJOUT_MAGASIN', "Ajout grande surface $name");
                setFlash('success', "Grande surface '$name' ajoutée avec succès !");
            }
        }
        redirect('supermarkets');
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            if ($id > 0 && !empty($name)) {
                $this->supermarketModel->update($id, [
                    'name'         => $name,
                    'color_hex'    => $_POST['color_hex'] ?? '#16A34A',
                    'website'      => trim($_POST['website'] ?? ''),
                    'stores_count' => (int)($_POST['stores_count'] ?? 1),
                    'active'       => isset($_POST['active']) ? 1 : 0
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'MODIF_MAGASIN', "Mise à jour grande surface $name");
                setFlash('success', "Grande surface '$name' mise à jour !");
            }
        }
        redirect('supermarkets');
    }

    public function delete(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $this->supermarketModel->delete($id);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'SUPPR_MAGASIN', "Suppression grande surface ID #$id");
                setFlash('success', 'Grande surface supprimée.');
            }
        }
        redirect('supermarkets');
    }
}
