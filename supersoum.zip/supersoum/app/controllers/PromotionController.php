<?php
/**
 * Promotion Controller
 */
require_once __DIR__ . '/../models/Promotion.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Supermarket.php';
require_once __DIR__ . '/../models/Admin.php';

class PromotionController {
    private Promotion $promotionModel;
    private Product $productModel;
    private Supermarket $supermarketModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->promotionModel = new Promotion();
        $this->productModel = new Product();
        $this->supermarketModel = new Supermarket();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        $promotions = $this->promotionModel->getAll();
        $products = $this->productModel->getAll([], 100, 0);
        $supermarkets = $this->supermarketModel->getAll(true);

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/promotions/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function store(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $productId = (int)($_POST['product_id'] ?? 0);
            $supermarketId = (int)($_POST['supermarket_id'] ?? 0);
            $origPrice = (float)($_POST['original_price'] ?? 0);
            $promoPrice = (float)($_POST['promo_price'] ?? 0);

            if ($productId > 0 && $supermarketId > 0 && $origPrice > 0) {
                $this->promotionModel->create([
                    'product_id'          => $productId,
                    'supermarket_id'      => $supermarketId,
                    'original_price'      => $origPrice,
                    'promo_price'         => $promoPrice,
                    'discount_percentage' => (int)($_POST['discount_percentage'] ?? 0),
                    'title'               => trim($_POST['title'] ?? ''),
                    'start_date'          => $_POST['start_date'] ?? date('Y-m-d'),
                    'end_date'            => $_POST['end_date'] ?? date('Y-m-d', strtotime('+14 days')),
                    'active'              => isset($_POST['active']) ? 1 : 0
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'AJOUT_PROMO', "Ajout promotion produit #$productId");
                setFlash('success', 'Promotion ajoutée avec succès !');
            } else {
                setFlash('danger', 'Veuillez remplir les informations requises de la promotion.');
            }
        }
        redirect('promotions');
    }

    public function update(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            $productId = (int)($_POST['product_id'] ?? 0);
            $supermarketId = (int)($_POST['supermarket_id'] ?? 0);
            $origPrice = (float)($_POST['original_price'] ?? 0);
            $promoPrice = (float)($_POST['promo_price'] ?? 0);

            if ($id > 0 && $productId > 0 && $supermarketId > 0) {
                $this->promotionModel->update($id, [
                    'product_id'          => $productId,
                    'supermarket_id'      => $supermarketId,
                    'original_price'      => $origPrice,
                    'promo_price'         => $promoPrice,
                    'discount_percentage' => (int)($_POST['discount_percentage'] ?? 0),
                    'title'               => trim($_POST['title'] ?? ''),
                    'start_date'          => $_POST['start_date'],
                    'end_date'            => $_POST['end_date'],
                    'active'              => isset($_POST['active']) ? 1 : 0
                ]);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'MODIF_PROMO', "Mise à jour promotion #$id");
                setFlash('success', 'Promotion modifiée avec succès !');
            }
        }
        redirect('promotions');
    }

    public function delete(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $this->promotionModel->delete($id);
                $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'SUPPR_PROMO', "Suppression promotion #$id");
                setFlash('success', 'Promotion supprimée.');
            }
        }
        redirect('promotions');
    }
}
