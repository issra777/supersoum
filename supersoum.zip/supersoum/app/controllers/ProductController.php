<?php
/**
 * Product Controller
 */
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Subcategory.php';
require_once __DIR__ . '/../models/Brand.php';
require_once __DIR__ . '/../models/Supermarket.php';
require_once __DIR__ . '/../models/ProductPrice.php';
require_once __DIR__ . '/../models/Admin.php';

class ProductController {
    private Product $productModel;
    private Category $categoryModel;
    private Subcategory $subcategoryModel;
    private Brand $brandModel;
    private Supermarket $supermarketModel;
    private ProductPrice $priceModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->productModel = new Product();
        $this->categoryModel = new Category();
        $this->subcategoryModel = new Subcategory();
        $this->brandModel = new Brand();
        $this->supermarketModel = new Supermarket();
        $this->priceModel = new ProductPrice();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        $filters = [
            'search'      => trim($_GET['search'] ?? ''),
            'category_id' => $_GET['category_id'] ?? '',
            'brand_id'    => $_GET['brand_id'] ?? '',
            'status'      => $_GET['status'] ?? '',
            'sort'        => $_GET['sort'] ?? 'newest',
            'promo_only'  => isset($_GET['promo_only']) && $_GET['promo_only'] == '1' ? 1 : null,
            'no_price'    => isset($_GET['no_price']) && $_GET['no_price'] == '1' ? 1 : null,
        ];

        $page = max(1, (int)($_GET['p'] ?? 1));
        $limit = 9; // Grid display
        $offset = ($page - 1) * $limit;

        $totalProducts = $this->productModel->countFiltered($filters);
        $totalPages = max(1, ceil($totalProducts / $limit));
        $products = $this->productModel->getAll($filters, $limit, $offset);

        // Fetch prices for each product to display best supermarket & comparison
        foreach ($products as &$p) {
            $p['prices_list'] = $this->productModel->getPrices((int)$p['id']);
        }

        $categories = $this->categoryModel->getAll(true);
        $brands = $this->brandModel->getAll();

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/products/index.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function show(): void {
        $id = (int)($_GET['id'] ?? 0);
        $product = $this->productModel->getById($id);

        if (!$product) {
            setFlash('danger', 'Produit introuvable.');
            redirect('products');
        }

        $prices = $this->productModel->getPrices($id);
        $supermarkets = $this->supermarketModel->getAll(true);

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/products/show.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function create(): void {
        $categories = $this->categoryModel->getAll(true);
        $brands = $this->brandModel->getAll();
        $supermarkets = $this->supermarketModel->getAll(true);

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/products/create.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function store(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('products');
        }

        $name = trim($_POST['name'] ?? '');
        $categoryId = (int)($_POST['category_id'] ?? 0);

        if (empty($name) || $categoryId <= 0) {
            setFlash('danger', 'Le nom du produit et la catégorie sont obligatoires.');
            redirect('products', ['action' => 'create']);
        }

        // Handle image upload
        $imageName = 'placeholder.png';
        if (!empty($_FILES['image']['name'])) {
            $uploaded = $this->handleImageUpload($_FILES['image']);
            if ($uploaded) {
                $imageName = $uploaded;
            }
        } elseif (!empty($_POST['default_image'])) {
            $imageName = sanitize($_POST['default_image']);
        }

        $data = [
            'name'           => $name,
            'barcode'        => trim($_POST['barcode'] ?? ''),
            'category_id'    => $categoryId,
            'subcategory_id' => !empty($_POST['subcategory_id']) ? (int)$_POST['subcategory_id'] : null,
            'brand_id'       => !empty($_POST['brand_id']) ? (int)$_POST['brand_id'] : null,
            'unit'           => trim($_POST['unit'] ?? '1 unité'),
            'description'    => trim($_POST['description'] ?? ''),
            'image'          => $imageName,
            'featured'       => isset($_POST['featured']) ? 1 : 0,
            'status'         => $_POST['status'] ?? 'active'
        ];

        $productId = $this->productModel->create($data);

        // Save prices for supermarkets
        if (!empty($_POST['prices']) && is_array($_POST['prices'])) {
            $this->priceModel->saveAllPricesForProduct($productId, $_POST['prices']);
        }

        $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'AJOUT_PRODUIT', "Ajout du produit ID #$productId ($name)");
        setFlash('success', "Le produit '$name' a été créé avec succès !");
        redirect('products', ['action' => 'show', 'id' => $productId]);
    }

    public function edit(): void {
        $id = (int)($_GET['id'] ?? 0);
        $product = $this->productModel->getById($id);

        if (!$product) {
            setFlash('danger', 'Produit introuvable.');
            redirect('products');
        }

        $categories = $this->categoryModel->getAll(true);
        $subcategories = $product['category_id'] ? $this->categoryModel->getSubcategories((int)$product['category_id']) : [];
        $brands = $this->brandModel->getAll();
        $supermarkets = $this->supermarketModel->getAll(true);
        $prices = $this->productModel->getPrices($id);

        // Index prices by supermarket_id for easy form binding
        $marketPrices = [];
        foreach ($prices as $p) {
            $marketPrices[$p['supermarket_id']] = $p;
        }

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/products/edit.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }

    public function update(): void {
        $id = (int)($_POST['id'] ?? 0);
        $product = $this->productModel->getById($id);

        if (!$product) {
            setFlash('danger', 'Produit introuvable.');
            redirect('products');
        }

        $name = trim($_POST['name'] ?? '');
        $categoryId = (int)($_POST['category_id'] ?? 0);

        if (empty($name) || $categoryId <= 0) {
            setFlash('danger', 'Le nom du produit et la catégorie sont obligatoires.');
            redirect('products', ['action' => 'edit', 'id' => $id]);
        }

        $data = [
            'name'           => $name,
            'barcode'        => trim($_POST['barcode'] ?? ''),
            'category_id'    => $categoryId,
            'subcategory_id' => !empty($_POST['subcategory_id']) ? (int)$_POST['subcategory_id'] : null,
            'brand_id'       => !empty($_POST['brand_id']) ? (int)$_POST['brand_id'] : null,
            'unit'           => trim($_POST['unit'] ?? '1 unité'),
            'description'    => trim($_POST['description'] ?? ''),
            'featured'       => isset($_POST['featured']) ? 1 : 0,
            'status'         => $_POST['status'] ?? 'active'
        ];

        // Handle image upload if provided
        if (!empty($_FILES['image']['name'])) {
            $uploaded = $this->handleImageUpload($_FILES['image']);
            if ($uploaded) {
                $data['image'] = $uploaded;
            }
        }

        $this->productModel->update($id, $data);

        // Update prices
        if (!empty($_POST['prices']) && is_array($_POST['prices'])) {
            $this->priceModel->saveAllPricesForProduct($id, $_POST['prices']);
        }

        $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'MODIFICATION_PRODUIT', "Mise à jour du produit ID #$id ($name)");
        setFlash('success', "Le produit '$name' a été mis à jour avec succès !");
        redirect('products', ['action' => 'show', 'id' => $id]);
    }

    public function delete(): void {
        $id = (int)($_POST['id'] ?? 0);
        $product = $this->productModel->getById($id);

        if ($product) {
            $this->productModel->delete($id);
            $this->adminModel->logActivity($_SESSION['admin_id'] ?? null, 'SUPPRESSION_PRODUIT', "Suppression du produit ID #$id (" . $product['name'] . ")");
            setFlash('success', "Le produit '" . htmlspecialchars($product['name']) . "' a été supprimé.");
        } else {
            setFlash('danger', 'Produit introuvable.');
        }

        redirect('products');
    }

    private function handleImageUpload(array $file): ?string {
        $allowed = ['jpg', 'jpeg', 'png', 'svg', 'webp'];
        $filename = $file['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed)) {
            return null;
        }

        $newFileName = 'prod_' . time() . '_' . rand(100, 999) . '.' . $ext;
        $dest = UPLOADS_PRODUCTS . $newFileName;

        if (!is_dir(UPLOADS_PRODUCTS)) {
            mkdir(UPLOADS_PRODUCTS, 0777, true);
        }

        if (move_uploaded_file($file['tmp_name'], $dest)) {
            return $newFileName;
        }

        return null;
    }
}
