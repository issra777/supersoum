<?php
/**
 * Dashboard Controller
 */
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Supermarket.php';
require_once __DIR__ . '/../models/Promotion.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/ProductPrice.php';
require_once __DIR__ . '/../models/Admin.php';

class DashboardController {
    private Product $productModel;
    private Category $categoryModel;
    private Supermarket $supermarketModel;
    private Promotion $promotionModel;
    private User $userModel;
    private ProductPrice $priceModel;
    private Admin $adminModel;

    public function __construct() {
        requireAuth();
        $this->productModel = new Product();
        $this->categoryModel = new Category();
        $this->supermarketModel = new Supermarket();
        $this->promotionModel = new Promotion();
        $this->userModel = new User();
        $this->priceModel = new ProductPrice();
        $this->adminModel = new Admin();
    }

    public function index(): void {
        // KPI counters
        $stats = [
            'total_products' => $this->productModel->countTotal(),
            'total_supermarkets' => $this->supermarketModel->countSupermarkets(),
            'active_promotions' => $this->promotionModel->countActive(),
            'total_users' => $this->userModel->countTotal(),
            'updated_prices_recent' => $this->priceModel->countUpdatedRecently(),
            'products_without_price' => $this->productModel->countWithoutPrices()
        ];

        // Chart 1: Products by Category
        $catData = $this->productModel->getCategoryDistribution();
        $chartCategories = [
            'labels' => array_column($catData, 'name'),
            'data' => array_column($catData, 'total')
        ];

        // Chart 2: Promotions by Supermarket
        $promoData = $this->promotionModel->getPromotionsBySupermarket();
        $chartPromotions = [
            'labels' => array_column($promoData, 'supermarket_name'),
            'data' => array_column($promoData, 'promo_count'),
            'colors' => array_column($promoData, 'color_hex')
        ];

        // Chart 3: Price Evolution (Monthly trend)
        $evolutionData = $this->priceModel->getMonthlyEvolution();
        if (empty($evolutionData)) {
            $evolutionData = [
                ['month_label' => 'Avr', 'avg_price' => 6.200],
                ['month_label' => 'Mai', 'avg_price' => 6.350],
                ['month_label' => 'Juin', 'avg_price' => 6.420],
                ['month_label' => 'Juil', 'avg_price' => 6.510],
                ['month_label' => 'Août', 'avg_price' => 6.600],
                ['month_label' => 'Sept', 'avg_price' => 6.680],
            ];
        }
        $chartEvolution = [
            'labels' => array_column($evolutionData, 'month_label'),
            'data' => array_map('floatval', array_column($evolutionData, 'avg_price'))
        ];

        // Chart 4: Products count by Supermarket
        $marketData = $this->supermarketModel->getAll(true);
        $chartSupermarkets = [
            'labels' => array_column($marketData, 'name'),
            'data' => array_column($marketData, 'total_products_priced'),
            'colors' => array_column($marketData, 'color_hex')
        ];

        // Recent Price Updates
        $recentUpdates = $this->priceModel->getRecentUpdates(6);

        // Recent Activity Logs
        $recentActivities = $this->adminModel->getRecentActivities(6);

        // Active Promotions highlight
        $topPromos = $this->promotionModel->getAll(true);
        $topPromos = array_slice($topPromos, 0, 4);

        require_once APP_PATH . 'views/layouts/header.php';
        require_once APP_PATH . 'views/admin/dashboard.php';
        require_once APP_PATH . 'views/layouts/footer.php';
    }
}
