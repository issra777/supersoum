# SuperSoum — Comparateur de Prix Grandes Surfaces Tunisie

Application de gestion & administration complète développée en PHP 8+ / MySQL / Bootstrap 5 / Chart.js selon le modèle MVC.

## Grandes Surfaces Comparées
- 🛒 **Carrefour**
- 🛒 **Géant**
- 🛒 **Monoprix**
- 🛒 **MG (Magasin Général)**
- 🛒 **Aziza**

## Structure du projet

```
supersoum/
├── app/
│   ├── controllers/
│   ├── models/
│   └── views/
│       ├── layouts/
│       ├── auth/
│       └── admin/
├── config/
├── database/
├── public/
│   ├── css/style.css
│   ├── js/app.js
│   └── images/
│       ├── products/
│       ├── supermarkets/
│       └── logo/
├── install.php
└── index.php
```

## Démarrage rapide sur XAMPP

1. Copiez ce dossier dans `C:\xampp\htdocs\supersoum`
2. Démarrez **Apache** et **MySQL** dans le panneau de contrôle XAMPP.
3. Ouvrez votre navigateur sur `http://localhost/supersoum/`
4. Connectez-vous avec :
   - **Identifiant :** `admin`
   - **Mot de passe :** `admin123`
