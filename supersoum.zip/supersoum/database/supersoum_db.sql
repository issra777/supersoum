-- SuperSoum Database Schema & Complete Demo Seed
-- Character Set: UTF8MB4

CREATE DATABASE IF NOT EXISTS `supersoum_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `supersoum_db`;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `admin_activity`;
DROP TABLE IF EXISTS `price_history`;
DROP TABLE IF EXISTS `promotions`;
DROP TABLE IF EXISTS `product_prices`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `brands`;
DROP TABLE IF EXISTS `subcategories`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `supermarkets`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `admins`;
DROP TABLE IF EXISTS `settings`;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Admins Table
CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `role` ENUM('superadmin', 'admin', 'editor') DEFAULT 'admin',
  `avatar` VARCHAR(255) DEFAULT 'default_admin.png',
  `last_login` DATETIME NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Users Table (Consumers / App Users)
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(20) NULL,
  `governorate` VARCHAR(50) DEFAULT 'Tunis',
  `status` ENUM('active', 'inactive', 'banned') DEFAULT 'active',
  `registered_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `last_active` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Supermarkets Table
CREATE TABLE `supermarkets` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `slug` VARCHAR(50) NOT NULL UNIQUE,
  `logo` VARCHAR(255) NOT NULL,
  `color_hex` VARCHAR(10) DEFAULT '#16A34A',
  `website` VARCHAR(255) NULL,
  `stores_count` INT DEFAULT 1,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Categories Table
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `icon` VARCHAR(50) DEFAULT 'bi-box-seam',
  `description` TEXT NULL,
  `sort_order` INT DEFAULT 0,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Subcategories Table
CREATE TABLE `subcategories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Brands Table
CREATE TABLE `brands` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `logo` VARCHAR(255) NULL,
  `origin` VARCHAR(50) DEFAULT 'Tunisie',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Products Table
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `slug` VARCHAR(200) NOT NULL,
  `barcode` VARCHAR(50) NULL UNIQUE,
  `category_id` INT NOT NULL,
  `subcategory_id` INT NULL,
  `brand_id` INT NULL,
  `unit` VARCHAR(50) DEFAULT '1L',
  `description` TEXT NULL,
  `image` VARCHAR(255) NOT NULL DEFAULT 'placeholder.png',
  `featured` TINYINT(1) DEFAULT 0,
  `status` ENUM('active', 'inactive', 'draft') DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`brand_id`) REFERENCES `brands`(`id`) ON DELETE SET NULL,
  INDEX idx_prod_cat (`category_id`),
  INDEX idx_prod_brand (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Product Prices Table
CREATE TABLE `product_prices` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `supermarket_id` INT NOT NULL,
  `price` DECIMAL(10,3) NOT NULL,
  `in_stock` TINYINT(1) DEFAULT 1,
  `last_updated` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_prod_market` (`product_id`, `supermarket_id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`supermarket_id`) REFERENCES `supermarkets`(`id`) ON DELETE CASCADE,
  INDEX idx_price (`price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Price History Table (For Evolution Graphs)
CREATE TABLE `price_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `supermarket_id` INT NOT NULL,
  `price` DECIMAL(10,3) NOT NULL,
  `recorded_date` DATE NOT NULL,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`supermarket_id`) REFERENCES `supermarkets`(`id`) ON DELETE CASCADE,
  INDEX idx_hist_date (`recorded_date`),
  INDEX idx_hist_prod (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Promotions Table
CREATE TABLE `promotions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `supermarket_id` INT NOT NULL,
  `original_price` DECIMAL(10,3) NOT NULL,
  `promo_price` DECIMAL(10,3) NOT NULL,
  `discount_percentage` INT NOT NULL,
  `title` VARCHAR(200) NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`supermarket_id`) REFERENCES `supermarkets`(`id`) ON DELETE CASCADE,
  INDEX idx_promo_active (`active`, `start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Admin Activity Table
CREATE TABLE `admin_activity` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT NULL,
  `action` VARCHAR(100) NOT NULL,
  `details` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Settings Table
CREATE TABLE `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(50) NOT NULL UNIQUE,
  `setting_value` TEXT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ========================================================
-- SEED DATA
-- ========================================================

-- Admins (Password is 'admin123' => $2y$10$iM1vN0V6bK7i1Tszx8pI1u86j/2rA/7oB5l0Q3k7qFwK5d3JpLh1m)
INSERT INTO `admins` (`id`, `username`, `email`, `password`, `full_name`, `role`, `avatar`) VALUES
(1, 'admin', 'admin@supersoum.tn', '$2y$10$VzYFk1bH4yFz/YjI05D37OG8LqH0L5r.OtxB9QG67hK4Jp2OQhR2y', 'Administrateur Principal', 'superadmin', 'admin.png');
-- Fallback with password_hash of admin123 directly updated in install.php

-- Supermarkets
INSERT INTO `supermarkets` (`id`, `name`, `slug`, `logo`, `color_hex`, `website`, `stores_count`, `active`) VALUES
(1, 'Carrefour', 'carrefour', 'carrefour.svg', '#004F9F', 'https://www.carrefour.tn', 95, 1),
(2, 'Géant', 'geant', 'geant.svg', '#E30613', 'https://www.geant.tn', 12, 1),
(3, 'Monoprix', 'monoprix', 'monoprix.svg', '#E3001B', 'https://www.snmvt.com', 88, 1),
(4, 'MG', 'mg', 'mg.svg', '#E2001A', 'https://www.mg.tn', 160, 1),
(5, 'Aziza', 'aziza', 'aziza.svg', '#F47B20', 'https://www.aziza.tn', 320, 1);

-- Categories (14 large categories)
INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `description`, `sort_order`, `active`) VALUES
(1, 'Alimentation', 'alimentation', 'bi-basket', 'Produits alimentaires de base et conserves', 1, 1),
(2, 'Boissons', 'boissons', 'bi-cup-straw', 'Eaux, sodas, jus, sirops et boissons chaudes', 2, 1),
(3, 'Produits laitiers', 'produits-laitiers', 'bi-egg', 'Lait, yaourts, beurres, fromages et crèmes', 3, 1),
(4, 'Fruits & Légumes', 'fruits-legumes', 'bi-apple', 'Fruits et légumes frais locaux et importés', 4, 1),
(5, 'Viandes', 'viandes', 'bi-fire', 'Viandes rouges, volailles et charcuterie', 5, 1),
(6, 'Poissons', 'poissons', 'bi-water', 'Poissons frais, fruits de mer et conserves', 6, 1),
(7, 'Surgelés', 'surgeles', 'bi-snow', 'Plats préparés, légumes et glaces surgelées', 7, 1),
(8, 'Épicerie', 'epicerie', 'bi-cart4', 'Pâtes, riz, huiles, épices, sauces et sucres', 8, 1),
(9, 'Boulangerie', 'boulangerie', 'bi-cake2', 'Pains, viennoiseries, biscottes et gâteaux', 9, 1),
(10, 'Hygiène & Beauté', 'hygiene-beaute', 'bi-person-heart', 'Savons, shampoings, soins dentaires et cosmétiques', 10, 1),
(11, 'Entretien', 'entretien', 'bi-droplet-half', 'Lessives, produits vaisselle, nettoyants maison', 11, 1),
(12, 'Bébé', 'bebe', 'bi-emoji-smile', 'Couches, lingettes, laits infantiles et petits pots', 12, 1),
(13, 'Maison', 'maison', 'bi-house', 'Papeterie, vaisselle, ustensiles et petit électroménager', 13, 1),
(14, 'Animaux', 'animaux', 'bi-heart-pulse', 'Nourriture et accessoires pour chats et chiens', 14, 1);

-- Subcategories
INSERT INTO `subcategories` (`id`, `category_id`, `name`, `slug`) VALUES
(1, 3, 'Lait & Boissons lactées', 'lait-boissons-lactees'),
(2, 3, 'Yaourts & Desserts', 'yaourts-desserts'),
(3, 3, 'Fromages & Beurres', 'fromages-beurres'),
(4, 2, 'Eaux minérales', 'eaux-minerales'),
(5, 2, 'Sodas & Gazéifiées', 'sodas-gazeifiees'),
(6, 2, 'Jus de fruits', 'jus-de-fruits'),
(7, 2, 'Cafés & Thés', 'cafes-thes'),
(8, 8, 'Pâtes alimentaires', 'pates-alimentaires'),
(9, 8, 'Riz & Céréales', 'riz-cereales'),
(10, 8, 'Huiles & Graisses', 'huiles-graisses'),
(11, 8, 'Conserves de tomates & Harissa', 'conserves-tomates-harissa'),
(12, 9, 'Biscuits & Goûters', 'biscuits-gouters'),
(13, 10, 'Soins capillaires & Shampoings', 'shampoings-soins'),
(14, 10, 'Hygiène bucco-dentaire', 'hygiene-dentaire'),
(15, 11, 'Lessives & Adoucissants', 'lessives-adoucissants'),
(16, 11, 'Papier Hygiénique & Essuie-tout', 'papier-hygienique'),
(17, 12, 'Couches & Lingettes', 'couches-lingettes'),
(18, 12, 'Alimentation bébé', 'alimentation-bebe');

-- Brands
INSERT INTO `brands` (`id`, `name`, `slug`, `origin`) VALUES
(1, 'Délice Danone', 'delice-danone', 'Tunisie'),
(2, 'Vitalait', 'vitalait', 'Tunisie'),
(3, 'Safia', 'safia', 'Tunisie'),
(4, 'Sabrine', 'sabrine', 'Tunisie'),
(5, 'Coca-Cola', 'coca-cola', 'International'),
(6, 'Boga', 'boga', 'Tunisie'),
(7, 'Randa', 'randa', 'Tunisie'),
(8, 'Warda', 'warda', 'Tunisie'),
(9, 'Cristal', 'cristal', 'Tunisie'),
(10, 'Jadida', 'jadida', 'Tunisie'),
(11, 'Sicam', 'sicam', 'Tunisie'),
(12, 'Saida', 'saida', 'Tunisie'),
(13, 'Président', 'president', 'France'),
(14, 'Le Petit Marseillais', 'le-petit-marseillais', 'France'),
(15, 'Signal', 'signal', 'International'),
(16, 'Ariel', 'ariel', 'International'),
(17, 'Lilies', 'lilies', 'Tunisie'),
(18, 'Pampers', 'pampers', 'International'),
(19, 'Café Ben Yedder', 'cafe-ben-yedder', 'Tunisie'),
(20, 'Papillon', 'papillon', 'Tunisie');

-- Products (18 realistic Tunisian staples with exact categories & units)
INSERT INTO `products` (`id`, `name`, `slug`, `barcode`, `category_id`, `subcategory_id`, `brand_id`, `unit`, `description`, `image`, `featured`, `status`) VALUES
(1, 'Lait Demi-Écrémé UHT 1L', 'lait-demi-ecreme-uht-1l', '6194000100011', 3, 1, 1, 'Brique 1L', 'Lait stérilisé UHT demi-écrémé riche en calcium et vitamines.', 'lait_delice.svg', 1, 'active'),
(2, 'Lait Stérilisé Vitalait 1L', 'lait-sterilise-vitalait-1l', '6194000100028', 3, 1, 2, 'Brique 1L', 'Lait demi-écrémé tunisien sélectionné de Mahdia.', 'lait_vitalait.svg', 0, 'active'),
(3, 'Eau Minérale Naturelle 1.5L', 'eau-minerale-naturelle-1-5l', '6194000200018', 2, 4, 3, 'Bouteille 1.5L', 'Eau minérale naturelle pure issue de la source Ain Safia.', 'eau_safia.svg', 1, 'active'),
(4, 'Eau Minérale Sabrine 1.5L', 'eau-minerale-sabrine-1-5l', '6194000200025', 2, 4, 4, 'Bouteille 1.5L', 'Eau de source naturelle légère et équilibrée.', 'eau_sabrine.svg', 0, 'active'),
(5, 'Coca-Cola Goût Original 1.5L', 'coca-cola-gout-original-1-5l', '5449000000996', 2, 5, 5, 'Bouteille 1.5L', 'Boisson gazeuse rafraîchissante aux extraits végétaux.', 'coca_cola.svg', 1, 'active'),
(6, 'Boga Cidre Boisson Gazeuse 1.5L', 'boga-cidre-boisson-gazeuse-1-5l', '6194000300015', 2, 5, 6, 'Bouteille 1.5L', 'Boisson gazeuse tunisienne emblématique au goût unique de caroube/cidre.', 'boga_cidre.svg', 1, 'active'),
(7, 'Spaghetti N°2 Randa 500g', 'spaghetti-n2-randa-500g', '6194000400012', 8, 8, 7, 'Paquet 500g', 'Pâtes alimentaires de qualité supérieure 100% semoule de blé dur.', 'pates_randa.svg', 1, 'active'),
(8, 'Couscous Fin Warda 1kg', 'couscous-fin-warda-1kg', '6194000400029', 8, 8, 8, 'Sachet 1kg', 'Couscous traditionnel tunisien grain fin pré-cuit à la vapeur.', 'couscous_warda.svg', 0, 'active'),
(9, 'Huile Végétale Raffinée Cristal 1L', 'huile-vegetale-raffinee-cristal-1l', '6194000500019', 8, 10, 9, 'Bouteille 1L', 'Huile de maïs pure pour cuisson, friture et assaisonnement.', 'huile_cristal.svg', 1, 'active'),
(10, 'Double Concentré de Tomate Sicam 800g', 'double-concentre-de-tomate-sicam-800g', '6194000600016', 8, 11, 11, 'Boîte 800g', 'Pur concentré de tomates tunisiennes mûries au soleil.', 'tomate_sicam.svg', 1, 'active'),
(11, 'Biscuits Major Gaufrette Saida 150g', 'biscuits-major-gaufrette-saida-150g', '6194000700013', 9, 12, 12, 'Paquet 150g', 'Gaufrettes croustillantes fourrées au chocolat noir.', 'biscuits_saida.svg', 1, 'active'),
(12, 'Pack 8 Yaourts Brassés Délice Fraise', 'pack-8-yaourts-brasses-delice-fraise', '6194000800010', 3, 2, 1, 'Pack 8x100g', 'Yaourt onctueux aux vrais morceaux de fraise.', 'yaourts_delice.svg', 1, 'active'),
(13, 'Fromage Carré Portion Président 24p', 'fromage-carre-portion-president-24p', '3228020100014', 3, 3, 13, 'Boîte 24 Portions', 'Fromage fondu riche en calcium pour petits déjeuners et goûters.', 'fromage_president.svg', 1, 'active'),
(14, 'Café Moulu Tradition Ben Yedder 250g', 'cafe-moulu-tradition-ben-yedder-250g', '6194000900017', 2, 7, 19, 'Paquet 250g', 'Mélange subtil d’Arabica et Robusta torréfié selon la tradition tunisienne.', 'cafe_ben_yedder.svg', 1, 'active'),
(15, 'Lessive Poudre Machine Ariel 3kg', 'lessive-poudre-machine-ariel-3kg', '4015600100018', 11, 15, 16, 'Baril 3kg', 'Lessive haute performance détachante même à basse température.', 'lessive_ariel.svg', 1, 'active'),
(16, 'Shampoing Extra Doux Le Petit Marseillais 250ml', 'shampoing-extra-doux-le-petit-marseillais-250ml', '3574660100012', 10, 13, 14, 'Flacon 250ml', 'Shampoing au lait d’amande douce et extrait de pomme pour toute la famille.', 'shampooing_lpm.svg', 0, 'active'),
(17, 'Dentifrice Signal White Now 75ml', 'dentifrice-signal-white-now-75ml', '8717163100015', 10, 14, 15, 'Tube 75ml', 'Dentifrice blancheur instantanée cliniquement prouvée.', 'dentifrice_signal.svg', 0, 'active'),
(18, 'Couches Bébé Maxi Pack Pampers Taille 4 (52pcs)', 'couches-bebe-maxi-pack-pampers-taille-4-52pcs', '4015400100015', 12, 17, 18, 'Pack 52 pièces', 'Couches ultra absorbantes avec barrières anti-fuites 12h.', 'couches_pampers.svg', 1, 'active'),
(19, 'Papier Toilette Confort Lilies 12 Rouleaux', 'papier-toilette-confort-lilies-12-rouleaux', '6194001100014', 11, 16, 17, 'Paquet 12r', 'Papier hygiénique 3 plis gaufré ultra doux et résistant.', 'papier_lilies.svg', 0, 'active'),
(20, 'Riz Blanc Long Grain Papillon 1kg', 'riz-blanc-long-grain-papillon-1kg', '6194001200011', 8, 9, 20, 'Sachet 1kg', 'Riz sélectionné naturellement parfumé non collant.', 'riz_papillon.svg', 0, 'active');

-- Product Prices (Comparing in Carrefour, Géant, Monoprix, MG, Aziza)
-- Product 1: Délice Lait 1L (Example from spec: MG 1.650, Aziza 1.620, Carrefour 1.590, Géant 1.600, Monoprix 1.680)
INSERT INTO `product_prices` (`product_id`, `supermarket_id`, `price`, `in_stock`) VALUES
(1, 1, 1.590, 1),
(1, 2, 1.600, 1),
(1, 3, 1.680, 1),
(1, 4, 1.650, 1),
(1, 5, 1.620, 1),

-- Product 2: Vitalait Lait 1L
(2, 1, 1.580, 1),
(2, 2, 1.590, 1),
(2, 3, 1.650, 1),
(2, 4, 1.630, 1),
(2, 5, 1.570, 1),

-- Product 3: Safia 1.5L
(3, 1, 0.780, 1),
(3, 2, 0.750, 1),
(3, 3, 0.820, 1),
(3, 4, 0.790, 1),
(3, 5, 0.730, 1),

-- Product 4: Sabrine 1.5L
(4, 1, 0.720, 1),
(4, 2, 0.700, 1),
(4, 3, 0.750, 1),
(4, 4, 0.710, 1),
(4, 5, 0.690, 1),

-- Product 5: Coca-Cola 1.5L
(5, 1, 2.750, 1),
(5, 2, 2.790, 1),
(5, 3, 2.850, 1),
(5, 4, 2.800, 1),
(5, 5, 2.690, 1),

-- Product 6: Boga Cidre 1.5L
(6, 1, 2.500, 1),
(6, 2, 2.480, 1),
(6, 3, 2.600, 1),
(6, 4, 2.550, 1),
(6, 5, 2.450, 1),

-- Product 7: Spaghetti Randa 500g
(7, 1, 0.890, 1),
(7, 2, 0.910, 1),
(7, 3, 0.950, 1),
(7, 4, 0.920, 1),
(7, 5, 0.870, 1),

-- Product 8: Couscous Warda 1kg
(8, 1, 1.790, 1),
(8, 2, 1.820, 1),
(8, 3, 1.890, 1),
(8, 4, 1.850, 1),
(8, 5, 1.750, 1),

-- Product 9: Huile Cristal 1L
(9, 1, 4.450, 1),
(9, 2, 4.500, 1),
(9, 3, 4.650, 1),
(9, 4, 4.590, 1),
(9, 5, 4.390, 1),

-- Product 10: Tomate Sicam 800g
(10, 1, 3.850, 1),
(10, 2, 3.900, 1),
(10, 3, 4.100, 1),
(10, 4, 3.950, 1),
(10, 5, 3.800, 1),

-- Product 11: Biscuits Saida 150g
(11, 1, 1.250, 1),
(11, 2, 1.200, 1),
(11, 3, 1.350, 1),
(11, 4, 1.300, 1),
(11, 5, 1.180, 1),

-- Product 12: Yaourts Délice Pack 8
(12, 1, 3.600, 1),
(12, 2, 3.550, 1),
(12, 3, 3.800, 1),
(12, 4, 3.700, 1),
(12, 5, 3.500, 1),

-- Product 13: Fromage Président 24p
(13, 1, 7.850, 1),
(13, 2, 7.900, 1),
(13, 3, 8.200, 1),
(13, 4, 7.990, 1),
(13, 5, 7.750, 1),

-- Product 14: Café Ben Yedder 250g
(14, 1, 3.200, 1),
(14, 2, 3.250, 1),
(14, 3, 3.400, 1),
(14, 4, 3.300, 1),
(14, 5, 3.150, 1),

-- Product 15: Lessive Ariel 3kg
(15, 1, 24.900, 1),
(15, 2, 25.500, 1),
(15, 3, 26.800, 1),
(15, 4, 25.900, 1),
(15, 5, 23.990, 1),

-- Product 16: Shampoing Le Petit Marseillais 250ml
(16, 1, 6.450, 1),
(16, 2, 6.500, 1),
(16, 3, 6.900, 1),
(16, 4, 6.650, 1),
(16, 5, 6.300, 1),

-- Product 17: Signal White Now 75ml
(17, 1, 4.800, 1),
(17, 2, 4.750, 1),
(17, 3, 5.200, 1),
(17, 4, 4.950, 1),
(17, 5, 4.600, 1),

-- Product 18: Pampers Maxi Pack 52pcs
(18, 1, 36.500, 1),
(18, 2, 37.000, 1),
(18, 3, 38.900, 1),
(18, 4, 37.500, 1),
(18, 5, 35.800, 1),

-- Product 19: Papier Lilies 12r
(19, 1, 9.800, 1),
(19, 2, 9.900, 1),
(19, 3, 10.500, 1),
(19, 4, 10.200, 1),
(19, 5, 9.500, 1),

-- Product 20: Riz Papillon 1kg
(20, 1, 3.100, 1),
(20, 2, 3.150, 1),
(20, 3, 3.300, 1),
(20, 4, 3.200, 1),
(20, 5, 2.990, 1);

-- Promotions (Realistic active supermarket discounts)
INSERT INTO `promotions` (`id`, `product_id`, `supermarket_id`, `original_price`, `promo_price`, `discount_percentage`, `title`, `start_date`, `end_date`, `active`) VALUES
(1, 15, 1, 24.900, 19.920, 20, 'Promo Éclat Ariel -20%', CURDATE() - INTERVAL 2 DAY, CURDATE() + INTERVAL 12 DAY, 1),
(2, 18, 5, 35.800, 28.640, 20, 'Spécial Bébé Aziza -20%', CURDATE() - INTERVAL 5 DAY, CURDATE() + INTERVAL 7 DAY, 1),
(3, 5, 2, 2.790, 2.230, 20, 'Festival Rafraîchissement Géant', CURDATE() - INTERVAL 1 DAY, CURDATE() + INTERVAL 10 DAY, 1),
(4, 13, 3, 8.200, 6.560, 20, 'Quinzaine Laitière Monoprix', CURDATE() - INTERVAL 3 DAY, CURDATE() + INTERVAL 8 DAY, 1),
(5, 10, 4, 3.950, 3.160, 20, 'Pack Épicerie MG Express', CURDATE() - INTERVAL 4 DAY, CURDATE() + INTERVAL 6 DAY, 1),
(6, 12, 1, 3.600, 2.700, 25, 'Goûter Délice Carrefour -25%', CURDATE() - INTERVAL 1 DAY, CURDATE() + INTERVAL 14 DAY, 1),
(7, 16, 2, 6.500, 4.875, 25, 'Beauté & Soins Géant -25%', CURDATE() - INTERVAL 6 DAY, CURDATE() + INTERVAL 4 DAY, 1),
(8, 14, 5, 3.150, 2.520, 20, 'Le Bon Café du Matin Aziza', CURDATE() - INTERVAL 2 DAY, CURDATE() + INTERVAL 15 DAY, 1);

-- Price History (Historical data across past months for Chart.js)
INSERT INTO `price_history` (`product_id`, `supermarket_id`, `price`, `recorded_date`) VALUES
(1, 1, 1.450, DATE_SUB(CURDATE(), INTERVAL 90 DAY)),
(1, 1, 1.520, DATE_SUB(CURDATE(), INTERVAL 60 DAY)),
(1, 1, 1.550, DATE_SUB(CURDATE(), INTERVAL 30 DAY)),
(1, 1, 1.590, CURDATE()),

(1, 4, 1.490, DATE_SUB(CURDATE(), INTERVAL 90 DAY)),
(1, 4, 1.580, DATE_SUB(CURDATE(), INTERVAL 60 DAY)),
(1, 4, 1.620, DATE_SUB(CURDATE(), INTERVAL 30 DAY)),
(1, 4, 1.650, CURDATE()),

(15, 1, 22.500, DATE_SUB(CURDATE(), INTERVAL 90 DAY)),
(15, 1, 23.500, DATE_SUB(CURDATE(), INTERVAL 60 DAY)),
(15, 1, 24.200, DATE_SUB(CURDATE(), INTERVAL 30 DAY)),
(15, 1, 24.900, CURDATE()),

(15, 5, 21.900, DATE_SUB(CURDATE(), INTERVAL 90 DAY)),
(15, 5, 22.800, DATE_SUB(CURDATE(), INTERVAL 60 DAY)),
(15, 5, 23.500, DATE_SUB(CURDATE(), INTERVAL 30 DAY)),
(15, 5, 23.990, CURDATE());

-- Demo Consumers
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `governorate`, `status`, `registered_at`) VALUES
(1, 'Mohamed Ben Salem', 'mohamed.bensalem@gmail.com', '+216 98 123 456', 'Tunis', 'active', DATE_SUB(NOW(), INTERVAL 25 DAY)),
(2, 'Sarra Trabelsi', 'sarra.trabelsi@yahoo.fr', '+216 55 987 654', 'Ariana', 'active', DATE_SUB(NOW(), INTERVAL 18 DAY)),
(3, 'Yassine Gharbi', 'yassine.gharbi@gnet.tn', '+216 22 345 678', 'Sousse', 'active', DATE_SUB(NOW(), INTERVAL 10 DAY)),
(4, 'Meriem Bouazizi', 'meriem.b@gmail.com', '+216 29 876 543', 'Sfax', 'active', DATE_SUB(NOW(), INTERVAL 5 DAY)),
(5, 'Karim Chahed', 'karim.chahed@outlook.com', '+216 50 112 233', 'Nabeul', 'active', DATE_SUB(NOW(), INTERVAL 2 DAY));

-- Admin Activity Log
INSERT INTO `admin_activity` (`admin_id`, `action`, `details`, `ip_address`, `created_at`) VALUES
(1, 'CONNEXION', 'Connexion réussie au panneau d\'administration', '127.0.0.1', DATE_SUB(NOW(), INTERVAL 2 HOUR)),
(1, 'MISE_A_JOUR_PRIX', 'Mise à jour des prix Lait Délice 1L', '127.0.0.1', DATE_SUB(NOW(), INTERVAL 1 HOUR)),
(1, 'NOUVELLE_PROMOTION', 'Ajout de la promotion Spécial Bébé Aziza', '127.0.0.1', DATE_SUB(NOW(), INTERVAL 30 MINUTE));

-- System Settings
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'SuperSoum'),
('site_tagline', 'Le 1er comparateur de prix des grandes surfaces en Tunisie'),
('contact_email', 'contact@supersoum.tn'),
('currency', 'DT'),
('currency_symbol', 'DT'),
('auto_best_price', '1'),
('notify_promo_expiring', '1'),
('items_per_page', '10'),
('alert_price_variation', '15'),
('maintenance_mode', '0');
